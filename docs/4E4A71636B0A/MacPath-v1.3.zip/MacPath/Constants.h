
#ifndef Constants_h
#define Constants_h

// #define DEBUG

#ifdef DEBUG

#define NSLog(FORMAT, ...) printf("%s\n\t%s\n",	\
		__PRETTY_FUNCTION__,		\
		[[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] \
		UTF8String]);

#else

#define NSLog(FORMAT, ...) printf("%s", \
		[[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] \
		UTF8String]);

#endif

//#define PzSLog(fmt, ...) NSLog((@"%s " fmt),   __PRETTY_FUNCTION__, ##__VA_ARGS__)

// prints boolean name and setting
//
#define NSLogBool(x) NSLog(@"%s: %@\n",#x, x ? @"true" : @"false" )           

#endif
