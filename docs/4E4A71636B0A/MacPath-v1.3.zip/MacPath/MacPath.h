#import <Foundation/Foundation.h>

#ifndef GetAliasPath_h
#define GetAliasPath_h

#define	VERBOSE		0x01
#define	LIST_TARGETS	0x02
#define LIST_URLPATH	0x04
#define LIST_COMPONENTS	0x08

#define IS_ALIAS	0x10
#define IS_WEBLOC	0x20

@interface MacPath : NSObject

@property (assign, nonatomic) int Flags;

/*
- (NSString*) programName;

- (void) displayVersion;
- (void) displayHelp;

- (NSURL*) targetOfAlias:(NSURL*) url;
- (BOOL) fileIsAlias: (NSString*) thePath;
- (BOOL) URLisAlias: (NSURL*) theURL;
*/

- (void) parseCommandLineArgv:(char * const *)argv argc:(int)argc;

@end

#endif
