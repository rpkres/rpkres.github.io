#import "MacPath.h"
#import "Constants.h"
#import <getopt.h>

NSString* const version = @"1.30.0";

@interface MacPath ()

- (NSString*) programName;
- (NSString*) osVersion;
- (void) displayHelp;

@end

@implementation MacPath


- (NSString*) programName
{
  return [NSProcessInfo processInfo].processName;
}

- (NSString*) osVersion
{
  return [[NSProcessInfo processInfo] operatingSystemVersionString];
}

- (void) displayVersion
{
  NSLog(@"Program Version %@\n", version);
  NSLog(@"MacOS %@\n", [self osVersion]);
}

- (void) displayHelp
{
  const char *pad="      ";

  NSLog(@"Usage: [options] %@ files...\n\n", [self programName]);
  NSLog(@"%s prints expanded paths of passed 'files'.\n\n", pad);

NSLog(@"%@", @"options:\n"
"\t-c | --components  Print extended url info.\n"
"\t-f | --file        If file is a Finder alias, just print the alias path.\n"
"\t-h | --help        Print this usage.\n"
"\t-t | --target      If file is a Finder alias, print the target path.\n"
"\t-u | --url         Print path as a url.\n"
"\t-V | --version     Display version info.\n"
"\n"
"\tWhen in target (default) mode:\n"
"\n"
"\t  If file is a Finder alias, the path to the original is printed.\n"
"\n"
"\t  If file is a Bookmark (.*loc), the full url including scheme\n"
"\t  (afp:, file:, http:, smb:, ssh:, vnc: etc.) is printed.\n"
"\n"
);
//"\t-v | -verbose     Verbose.\n"

}		/* eo displayHelp */

//	Call method based on name - basic checking for return class type,
//	which should be a NSString.
//
- (void) printURLselectorString:(NSString*)name url:(NSURL*) url
{
SEL aSelector = NSSelectorFromString(name);

  if( ! [url respondsToSelector:aSelector ] ) {
    NSLog(@"Method does not respond to name: '%@'\n", name);
    return;
  }

  //	This tests for the type of return class - and whether there's
  //	actually any value set.
  //
  if( ! [[url performSelector:aSelector] 
                isKindOfClass:[NSString class]] ){
//    NSLog(@"Method name: '[url %@]' does not return a NSString\n", name);
    return;
  }

  NSString* result = [url performSelector:aSelector];

//  const char *fmtName = [name cStringUsingEncoding:
//                              NSUTF8StringEncoding];

  if ( [result length] != 0 ) {
    const char *fmtName = [name UTF8String];
    NSLog(@"%18s: %@\n", fmtName, result );
  }

}			/* eo printURLselectorString */

//	Call method based on name - basic checking for return class type,
//	which should be a NSNumber.
//
- (void) printURLselectorNumber:(NSString*)name url:(NSURL*) url
{
SEL aSelector = NSSelectorFromString(name);

  if( ! [url respondsToSelector:aSelector ] ) {
    NSLog(@"Method does not respond to name: '%@'\n", name);
    return;
  }

  //	This tests for the type of return class - and whether there's
  //	actually any value set.
  //
  if( ! [[url performSelector:aSelector] 
                isKindOfClass:[NSNumber class]] ){
//    NSLog(@"Method name: '[url %@]' does not return a NSNumber\n", name);
    return;
  }

  NSNumber* result = [url performSelector:aSelector];

  const char *fmtName = [name UTF8String];
  NSLog(@"%18s: %@\n", fmtName, result );

}			/* eo printURLselectorNumber */


/*
 *	Too tired to figure this out now - should be able to determine
 *	call based on 'component'. Clean up later.
 */
- (void) printURLcomponents:(NSURL*) url 
{
NSString* comp = @"scheme";

  //	All of these [url selectorName] must return a string
  //
  [self printURLselectorString:@"scheme" url:url];
  [self printURLselectorString:@"user" url:url];
  [self printURLselectorString:@"password" url:url];
  [self printURLselectorString:@"host" url:url];
  [self printURLselectorNumber:@"port" url:url];
  [self printURLselectorString:@"pathExtension" url:url];
  [self printURLselectorString:@"query" url:url];
  [self printURLselectorString:@"fragment" url:url];
  [self printURLselectorString:@"lastPathComponent" url:url];
  [self printURLselectorString:@"relativePath" url:url];
  [self printURLselectorString:@"absoluteString" url:url];

// NSNumber
//  if ( [url port] ) {
//    NSLog(@"%18s: %@\n", "port", [url port] );
//  }

  NSLog(@"\n");

}		/* eo printURLcomponents() */

//	main routine
//
- (void) parseCommandLineArgv:(char * const *)argv argc:(int)argc
{
  static struct option options[] = {
    { "help",		no_argument,            0,              '?' },
    { "components",	no_argument,            0,              'c' },
    { "file",		no_argument,            0,              'f' },
    { "help",		no_argument,            0,              'h' },
    { "target",		no_argument,            0,              't' },
    { "url",	        no_argument,            0,              'u' },
    { "version",	no_argument,            0,              'V' },
    { "verbose",	no_argument,            0,              'v' },
    { 0,		0,                      0,               0  }
  };

  if ( argc < 2 ) {
    [self displayHelp];
    return;
  }

  int option_char;
  int option_index;

  self.Flags = LIST_TARGETS;	// default mode

  while ((option_char = getopt_long(argc, argv, "?cfhtuVv", 
	  options, &option_index)) != -1)
  {
    switch (option_char) {
      case 'c': self.Flags|= LIST_COMPONENTS; break;
      case 'f': self.Flags&= ~(LIST_TARGETS); break;
      case 't': self.Flags|= LIST_TARGETS;    break;
      case 'u': self.Flags|= LIST_URLPATH;    break;
      case '?':
      case 'h':
	[self displayHelp];
	return;
	break;
      case 'V':
	[self displayVersion];
	return;
	break;
      case 'v': self.Flags|= VERBOSE; break;
    }		// eo switch

  }		// eo while

//  NSLog(@"argc: %d  optind: %d\n", argc, optind );

//  [self parsePathArguments:argv argc:argc ];
  [self parsePathArguments:&argv[optind] argc:argc - optind ];

}		/* eo parseCommandLineArgv */

//
//	Given the passed url, see if it contains data, if so look
//	
- (NSURL *) urlFromWeblocFile:(NSURL*) theURL {

  NSData* data = [NSData dataWithContentsOfURL:theURL];

  if (!data) { return nil; }

  NSError* error;
  NSDictionary *dict = [NSPropertyListSerialization 
			propertyListWithData:data
                        options:NSPropertyListImmutable
                        format:nil error:&error];
  
  if (!dict) { return nil; }

  NSString *urlString = dict[@"URL"];
  NSURL* result = [NSURL URLWithString:urlString];

  return result;

}		/* eo urlFromWeblocFile */

//
//	Above method seems to work better, keeping this around.
//	
- (NSString*) getWeblocURL2:(NSURL*) theURL {

    NSData* data = [NSData dataWithContentsOfURL:theURL];

    if (!data) { return nil; }

    NSError* error;
    id properties = [NSPropertyListSerialization 
                     propertyListWithData:data 
                     options:NSPropertyListImmutable 
       		     format:nil error:&error];

    if (!properties) { return nil; }

    NSArray* array = [properties valueForKeyPath:@"URL"];

    if (!array) { return nil; }

    if (![array isKindOfClass:[NSString class]]){
      return nil;
    }

    //	Not sure if this will hold up for multiple URL keys
    //
    NSString *result = [array description];

    return result;

}		/* eo getWeblocURL */

- (void) parsePathArguments:(char * const *)argv argc:(int)argc
{ 
NSURL*    theURL = nil;
NSURL*	  tgtURL = nil;
NSURL*    useURL = nil;
NSString* path = nil;
NSString* program = [self programName];
NSNumber* number = nil;
int	  listMode;
BOOL	  isAlias = false;

  for (int i = 0; i < argc; i++) {

    path = [NSString stringWithUTF8String:argv[i]];
   
    //	Check passed path exists, if not skip 
    //
    if (! [[NSFileManager defaultManager]fileExistsAtPath:path]) {
      NSLog(@"%@: Skipping. File does not exist %@.\n", program, path);
      continue;
    }   

    theURL = [NSURL fileURLWithPath:path ];

    if (! theURL ) {
      NSLog(@"%@: Can't form a URL from path %@\n.", program, path);
      exit(3);
    }

    useURL = theURL;			// url used may change later...

    //		Check if the url/file is an alias
    //
    number = nil;
    [theURL getResourceValue:&number forKey:NSURLIsAliasFileKey error:nil];
    isAlias = [number boolValue];

    if ( isAlias ) {

      tgtURL = [NSURL URLByResolvingAliasFileAtURL:theURL
		      options:NSURLBookmarkResolutionWithoutUI
                      error:nil]; 

      if (! tgtURL ) {
        NSLog(@"%@: Skipping. Can't get target url for '%@'.\n",program,path);
	continue;
      }

      //	set useURL to the target if LIST_TARGETS is set
      //
      if ( self.Flags & LIST_TARGETS ) {
        useURL = tgtURL;
      }

      self.Flags|= IS_ALIAS;

    } 		// eo if isAlias


    //	special case for .*loc files - the 'target' will be the
    //	url contained in the plist data inside the file.
    //
    if ( self.Flags & LIST_TARGETS ) {
      NSURL* bmkURL = [self urlFromWeblocFile:theURL];

      if ( bmkURL ) {
        useURL = bmkURL;
        self.Flags|= IS_WEBLOC;
      }
    }		// eo flags & LIST_TARGETS

    listMode = self.Flags & ( LIST_URLPATH | LIST_COMPONENTS );

//NSLog(@"listMode: %#.x\n", listMode);

    switch ( listMode ) {
      case LIST_URLPATH:
        NSLog(@"%@\n", [useURL absoluteString] );
        break;
      case LIST_COMPONENTS:
        [self printURLcomponents: useURL];
        break;
      default:
        if ( self.Flags & IS_WEBLOC ) {
          NSLog(@"%@\n", [useURL absoluteString] );
        } else {
          NSLog(@"%@\n", [useURL path] );
        }
        break;
    }		// eo switch listMode

    self.Flags&= ~(IS_ALIAS | IS_WEBLOC);	// turn off bits

  }		// eo for i

}		// eo parseCommandLineArgv

@end
