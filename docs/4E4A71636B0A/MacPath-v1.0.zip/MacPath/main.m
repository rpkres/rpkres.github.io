#import <Foundation/Foundation.h>
#import "MacPath.h"

int main ( int argc, char * argv[] ) 
{ 

//  @autoreleasepool {
        MacPath* tag = [MacPath new];

        [tag parseCommandLineArgv:argv argc:argc];

//        [tag performOperation];
//  }
  return 0;

}			/* eo main() */
