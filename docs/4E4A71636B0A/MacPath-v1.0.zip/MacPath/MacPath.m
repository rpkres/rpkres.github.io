#import "MacPath.h"
#import "Constants.h"
#import <getopt.h>

NSString* const version = @"1.00.0";

@interface MacPath ()

- (NSString*) programName;
- (NSString*) osVersion;
- (void) displayHelp;

@end

@implementation MacPath


- (NSString*) programName
{
  return [NSProcessInfo processInfo].processName;
}

- (NSString*) osVersion
{
  return [[NSProcessInfo processInfo] operatingSystemVersionString];
}

- (void) displayVersion
{
  NSLog(@"Program Version %@\n", version);
  NSLog(@"MacOS %@\n", [self osVersion]);
}

- (void) displayHelp
{
  const char *pad="      ";

  NSLog(@"Usage: [options] %@ files...\n\n", [self programName]);
  NSLog(@"%s prints expanded paths of passed 'files'.\n\n", pad);

NSLog(@"%@", @"options:\n"
"\t-a | --absolute    Print absolute path as a url.\n"
"\t-c | --components  Print extended url info.\n"
"\t-f | --file        If file is a Finder alias, just print the alias path.\n"
"\t-h | --help        Print this usage.\n"
"\t-t | --target      If file is a Finder alias, print the target path.\n"
"\t-V | --version     Display version info.\n"
"\n"
"\t                   Note. the default is to print the target path\n"
"\t                   if file is an alias, override with -f.\n"
);
//"\t-v | -verbose     Verbose.\n"


}		/* eo displayHelp */

/*
 *	Too tired to figure this out now - should be able to determine
 *	call based on 'component'. Clean up later.
 */
- (void) printURLcomponents:(NSURL*) url 
{
NSString* comp = @"scheme";

  if ( [url baseURL] ) {
    NSLog(@"%18s: %@\n", "baseURL", [url baseURL] );
  }
  if ( [url scheme] ) {
    NSLog(@"%18s: %@\n", "scheme", [url scheme] );
  }
  if ( [url user] ) {
    NSLog(@"%18s: %@\n", "user", [url user] );
  }
  if ( [url password] ) {
    NSLog(@"%18s: %@\n", "password", [url password] );
  }
  if ( [url host] ) {
    NSLog(@"%18s: %@\n", "host", [url host] );
  }
  if ( [url port] ) {
    NSLog(@"%18s: %@\n", "port", [url port] );
  }
//  if ( [url pathComponents] ) {
//    NSLog(@"%18s: %@\n", "pathComponents", [url pathComponents] );
//  }
  if ( [url pathExtension] ) {
    NSLog(@"%18s: %@\n", "pathExtension", [url pathExtension] );
  }
  if ( [url query] ) {
    NSLog(@"%18s: %@\n", "query", [url query] );
  }
  if ( [url fragment] ) {
    NSLog(@"%18s: %@\n", "fragment", [url fragment] );
  }
  if ( [url lastPathComponent] ) {
    NSLog(@"%18s: %@\n", "lastPathComponent", [url lastPathComponent] );
  }
  if ( [url relativePath] ) {
    NSLog(@"%18s: %@\n", "relativePath", [url relativePath] );
  }
  if ( [url standardizedURL] ) {
    NSLog(@"%18s: %@\n", "standardizedURL", [url standardizedURL] );
  }
  if ( [url absoluteURL] ) {
    NSLog(@"%18s: %@\n", "absoluteURL", [url absoluteURL] );
  }

}		/* eo printURLcomponents() */

//	main routine
//
- (void) parseCommandLineArgv:(char * const *)argv argc:(int)argc
{
  static struct option options[] = {
    { "absolute",	no_argument,            0,              'a' },
    { "components",	no_argument,            0,              'c' },
    { "file",		no_argument,            0,              'f' },
    { "target",		no_argument,            0,              't' },
    { "help",		no_argument,            0,              '?' },
    { "help",		no_argument,            0,              'h' },
    { "version",	no_argument,            0,              'V' },
    { "verbose",	no_argument,            0,              'v' },
    { 0,		0,                      0,               0  }
  };

  if ( argc < 2 ) {
    [self displayHelp];
    return;
  }

  int option_char;
  int option_index;

  self.Flags = LIST_TARGETS;	// default mode

  while ((option_char = getopt_long(argc, argv, "?acfthVv", 
	  options, &option_index)) != -1)
  {
    switch (option_char) {
      case 'a': self.Flags|= LIST_ABSPATH;    break;
      case 'c': self.Flags|= LIST_COMPONENTS; break;
      case 'f': self.Flags&= ~(LIST_TARGETS); break;
      case 't': self.Flags|= LIST_TARGETS;    break;
      case '?':
      case ':':
      case 'h':
	[self displayHelp];
	return;
	break;
      case 'V':
	[self displayVersion];
	return;
	break;
      case 'v': self.Flags|= VERBOSE; break;
    }		// eo switch

  }		// eo while

//  NSLog(@"argc: %d  optind: %d\n", argc, optind );

//  [self parsePathArguments:argv argc:argc ];
  [self parsePathArguments:&argv[optind] argc:argc - optind ];

}		/* eo parseCommandLineArgv */

- (void) parsePathArguments:(char * const *)argv argc:(int)argc
{ 
NSURL*    theURL = nil;
NSURL*	  tgtURL = nil;
NSURL*    useURL = nil;
NSString* path = nil;
NSString* program = [self programName];
NSNumber* number = nil;
BOOL	  isAlias = false;

  for (int i = 0; i < argc; i++) {

    path = [NSString stringWithUTF8String:argv[i]];
    theURL = [NSURL fileURLWithPath:path ];

    if (! theURL ) {
      NSLog(@"%@: Can't form a URL from path %@\n", program, path);
      exit(3);
    }

    useURL = theURL;

    //		Check if the url/file is an alias
    //
    number = nil;
    [theURL getResourceValue:&number forKey:NSURLIsAliasFileKey error:nil];
    isAlias = [number boolValue];

//    NSLog(@"\tisAlias: %d\n", isAlias);
//NSLogBool(isAlias);

    if ( isAlias ) {

      tgtURL = [NSURL URLByResolvingAliasFileAtURL:theURL
			options:NSURLBookmarkResolutionWithoutUI
                        error:nil]; 

      if (! tgtURL ) {
        NSLog(@"%@: Skipping. Can't get target url for '%@'\n\n",program,path);
	continue;
      }

      //	set useURL to the target if flagged option
      //
      if ( self.Flags & LIST_TARGETS ) {
        useURL = tgtURL;
      }

    } 		// eo if isAlias

    int oFlags = self.Flags & ( LIST_ABSPATH | LIST_COMPONENTS );

    switch ( oFlags ) {
      case LIST_ABSPATH:
        NSLog(@"%@\n", [useURL absoluteString] );
        break;
      case LIST_COMPONENTS:
        [self printURLcomponents: useURL];
        break;
      default:
        NSLog(@"%@\n", [useURL path] );
        break;
    }		// eo switch oFlags

    if ( i < (argc -1)) {
      NSLog(@"\n");
    }

  }		// eo for i

}		// eo parseCommandLineArgv

@end

/*
      [tgtURL getResourceValue:&number 
			forKey:NSURLIsDirectoryKey error:nil];
      BOOL isDirectory = [number boolValue];

      if ( isDirectory ) {
        NSString* suffix = @"/";
        targetPath = [NSString stringWithFormat:@"%@%@", 
				[tgtURL path],suffix];
      }
*/
