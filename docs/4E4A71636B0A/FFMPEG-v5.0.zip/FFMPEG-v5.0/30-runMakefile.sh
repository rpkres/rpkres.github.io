#!/bin/bash

set -eu                         # -e stop on errors, -u stop on unset vars

  inPath="/Volumes/iPadM/AW Downloads/Converted/%05d.jpg"

#  lutPath="LUTS/Generic LOG to Rec.709/U-9990-LTR.cube"
  lutPath="LUTS/Technicolor CineStyle to Rec.709/U-TECHNICOLOR-CINESTYLE-LTR.cube"
#  lutPath="NO-LUT"

  outName=$(basename "${lutPath}" .cube)
  outName="${outName/U-/}"			# strip U-
  outName="${outName/-LTR/}"			# strip -LTR

  outPath="MP4/${outName}.mp4"

  type=mp4
  start=2426
  width=850

#	Special case - good for quick tests. This env variable gets checked
#	by the main ffmpeg script, if defined it will only process $nframes
#
#export nframes=240

  #     This is the proper way to define 23.976 and 29.97 fps for film.
  #
  #             fps=24000/1001  = 23.976 
  #             fps=30000/1001  = 29.970
  #
  fps=24
#  fps="((${fps}*1000)/1001)"

#  overlay=false

# 01-convertDpx.sh start width type fps overlay lutPath inPath outPath

  make run-script 	\
	   		start=${start:-1}		\
	   		width=${width:-1.0} 		\
  			type=${type} 			\
			fps="\"${fps:-24}\""		\
			overlay=${overlay:-true}	\
			lutPath="\"${lutPath}\"" 	\
	   		inPath="\"${inPath}\""		\
           		outPath="\"${outPath}\""

exit 0
