#!/bin/bash

#	Create a string suitable for using in a ffmpeg video filter argument.
#
#	The following variables are global and must be defined in the
#	main script:
#
#		$theStart
#		$theFilmFps
#		$addTimeCodeInfo
#
function BuildTextOverlay()
{
local theString="${1}"
local fontSize
local fontOptions
local outString=""

  #
  #	Font size is based on image height but has a min max - expression
  #	notation is in ffmpeg format. 
  #
  local fontMinSize=12
  local fontMaxSize=24
  fontSize="clip( (h*.035)\, ${fontMinSize}\, ${fontMaxSize})"

  #	Location on Mac of various fonts
  #
  fontFile="/System/Library/Fonts/Monaco.dfont"
#  fontFile="/Library/Fonts/SF-Compact-Display-Medium.otf"
#  fontFile="/Library/Fonts/Verdana.ttf"
#  fontFile="/Library/Fonts/Courier New.ttf"
#  fontFile="/Library/Fonts/Courier New Bold.ttf"
  local fontColor="white"

  local boxColor="black@.6"			# 60% opacity
  local boxBorder=8

  local lOffset="(clip((${fontSize}*1)\, 30\, 60))"
  local rOffset="((w-${lOffset})-text_w)"
  local cOffset="(w-text_w)/2"

  yOffset1="(h-((${fontSize}*3.5)+(${boxBorder}*2)))"
  yOffset2="(h-(${fontSize}*2.5))"

  fontOptions="fontsize=${fontSize}:fontcolor=${fontColor}:fontfile=${fontFile}
:box=1:boxcolor=${boxColor}:boxborderw=${boxBorder}"

  local sourceFileNumber=($theStart)
#	:text='\ %{eif\\:n\\:d\\:4} %{eif\\:n\\:d\\:7}\ '

  #	lhs text - frame number
  #
  outString+="drawtext=expansion=normal
	:text='\ %{eif\\:n\\:d\\:4} %{eif\\:n+${sourceFileNumber}-1\\:d\\:7}\ '
	:start_number=1	
	:x=${lOffset}
	:y=${yOffset2}
	:${fontOptions}"

  #	add TC info if flagged
  #
  if [ "${addTimeCodeInfo}" == "true" ]; then
    #	rhs text - timecode
    #
    outString+=",drawtext=expansion=normal
	:timecode='00\:00\:00\:00'
       	:timecode_rate=${theFilmFps}
       	:x=${rOffset}
	:y=${yOffset2}
	:${fontOptions}"

  fi		# eo if $addTimeCodeInfo true

  #	if $theString is not empty add to filter
  #
  if [ "${theString}" != "" ]; then

    #	center text - draw $theString
    #
    outString+=",drawtext=expansion=normal
	:text='\ ${theString}\ '
	:x=${cOffset}
	:y=${yOffset1}
	:${fontOptions}"

  fi		# eo if $theString is not empty

  echo "${outString}"

}			# eo BuildTextOverlay()


#	Print Usage and exit
#
function Usage()
{
local theScript=$(basename "${0}")

cat<<EOD

Usage:	${theScript} start width type fps overlay lutPath inPath outPath

	start		- Start frame offset number of first file in inPath.
	width		- Width either a multiplier or fixed value integer.
	type 		- Can be one of: jpeg, jpg, mjpg, mjpeg, mp4, png, 
			  prores, tif or tiff.
	fps 		- Gets modified to yield 23.976 or 29.97 etc.
	overlay		- Frame number and lut used will be overlayed.
	lutFile 	- A 3D look up table file (.cube).
	inPath		- Specify with ffmpeg globbed notation.
	outPath		- Specify with globbed notation.

EOD

exit 1
}		# eo Usage()

function LongUsage()
{
local theScript=$(basename "${0}")

cat<<EOD

Usage:	${theScript} start width type fps overlay lutPath inPath outPath

	${theScript} uses ffmpeg to convert a sequence of .dpx images.
	The sequence can either be another sequence or all the frames
	are embedded into a single movie file.

	start		- Start frame offset number of first file in inPath

	width		- If a float is used, the input files width
			  is multiplied by the value specified.

			  e.g  0.5  -  scale the input images by 50%.

			  If an integer is specified, it will be used for
			  the absolute output width.

			  e.g 1024  -  sets output width to 1024

			  notes.

			  Setting width to 1 or 1.0 should perform no
			  scaling at all.

			  The height will be automatically calculated 
			  based on the input image aspect ratio.

			  Some codecs require even width/height to be exactly 
			  divisable by a specific size (often 2,4,8 etc.) and
			  will barf. So try a different value.

	type 		  Can be one of:

	  jpeg | jpg	-  Sequence of image files.
	  mjpg | mjpeg	- .mov container with motion-jpeg encoded frames.
	  mp4		- .mp4 video container with h.264 encoded frames.
	  png		-  Sequence of image files.
	  prores	- .mov container with prores encoded frames.
	  tif | tiff	-  Sequence of image files.

	fps 		- Currently hardcoded to being multiplied by 1000 and
	      		  divided by 1001. 

	      		  e.g. '24' will become 24000/1001 yielding 23.976 fps 
		    	  which is correct for film.

	overlay		- If 'true' frame number and lut used will be 
			  overlayed on the output frames.

			  TimeCode is also overlayed if the output is a
			  video container.

	lutFile 	- A 3D look up table file (.cube) applied to 
			  the input frames. 

			  If set to NO-LUT, then no lut will be applied.

	inPath		- specify with ffmpeg globbed notation, e.g.
			
			  ../DPX/%07d.dpx

			  would look for all files padded with seven zeros,
			  like 
				../DPX/0013417.dpx
				../DPX/0013418.dpx
				../DPX/0013419.dpx

			  note that the first file number read is via the
			  first argument, 'start'.

	outPath		- specify with globbed notation, you can modify 
			  the zero padding to fewer than 'inPath' for
			  image sequences, e.g. 

				TIFF/%05d.tiff

EOD

exit 1
}		# eo LongUsage()
