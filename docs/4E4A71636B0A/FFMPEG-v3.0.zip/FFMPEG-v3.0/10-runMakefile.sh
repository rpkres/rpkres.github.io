#!/bin/bash

set -eu                         # -e stop on errors, -u stop on unset vars

#	You can over-ride any of the variables in the Makefile
#	by setting them on the command line.
#
#	Makes testing a lot easier, especially with wedges and testing
#	itterations.
#
#	Worst part is extra escaping of strings that contain spaces as Make 
#	handles them differently.
#

#	Simple use case - just want to change the width
#
function OverrideSimple()
{
  make jpg width=960
}

#	more complex - different lut and outFile globbing etc. some
#	paths have spaces.
#
function OverrideStrings()
{
local lutPath
local outName
local jpgPath

  lutPath="LUTS/Generic LOG to Rec.709/U-9990-LTR.cube"
  outName=$(basename "${lutPath}" .cube)

  jpgPath="JPEG/${outName}.%05d.jpg"

  make jpg lutPath="\"${lutPath}\"" \
	   jpgPath="\"${jpgPath}\"" \
	   width=960

}		# eo OverrideStrings()

#	even more complex - loop over a list of luts, using the main part
#	of the name for naming new image files.
#
function MakeLUTwedge()
{
local i
local list
local lutPath
local outName
local jpgPath

#	IFS is only being overridden for this definition. Without it,
#	white space will split paths.
#
IFS=$'\n' list="
NO-LUT
LUTS/Generic LOG to Rec.709/U-9995-LTR.cube
LUTS/Generic LOG to Rec.709/U-9997-LTR.cube
LUTS/Technicolor CineStyle to Rec.709/U-TECHNICOLOR-CINESTYLE-LTR.cube
"

  for i in ${list}
  do
    lutPath="${i}"
    outName=$(basename "${lutPath}" .cube)

    jpgPath="JPEG/${outName}.%05d.jpg"

    make jpg lutPath="\"${lutPath}\"" \
	     jpgPath="\"${jpgPath}\"" \
	     width=960

  done		# for i in $list

}		# eo MakeLUTwedge()

#	Uncomment to run funtions - they must be defined before being called.
#
# OverrideSimple
# OverrideStrings
# MakeLUTwedge

  #	You don't need the functions of course, but are cleaner for
  #	more complex setups
  #
  #	Here we just run the makefile changing a couple of settings
  #
  make jpg fps=30 width=960

exit 0
