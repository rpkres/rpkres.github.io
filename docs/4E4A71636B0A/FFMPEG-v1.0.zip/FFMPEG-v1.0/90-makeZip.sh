#!/bin/bash

set -eu                         # -e stop on errors, -u stop on unset vars
                                # note, exits in sourced functions don't work

#local vers="${1}"

function MakeZip()
{
local iDir="${1}"
local oDir="${2}"
local cList
local dName
local bName
local zipFile
local func="MakeZip"

  if [ ! -d "${iDir}" ]; then
    echo "Skipping. Directory doesn't exist: '${iDir}'"
    return
  fi

  if [ ! -d "${oDir}" ]; then mkdir -p "${oDir}"; fi

  echo "Stripping .DS_Store files..."

  find "${iDir}" -name ".DS_Store" -print -exec /bin/rm {} \;
  echo

  #
  #     List of file types that are already compressed, no need to
  #     waste cpu trying to re-compress.
  #
#  cList=".Z:.zip:.tiff:.jgp:.psd:.mp4:.mpg:.vob:.VOB:.img:.mov"


  dName=$(dirname "${iDir}")    # Get the leading part of $iDir in case it's
                                # a full path.

  bName=$(basename "${iDir}")   # Just the last part of the path name of $iDir
                                # in case a full path is given.
                                #
                                # This will be used to construct a matching
                                # name for the zip file.

  #     If in same directory, just blank out $dName
  #     else append a slash
  #
  if [ "${dName}" = "." ]; then 
    dName=""
  else                          
    dName="${dName}/"           
  fi

#  zipFile="${bName}.zip"        
#  zipFile="${oDir}/${bName}-${vers}.zip"        
  zipFile="${oDir}/${bName}.zip"        

  echo "${func}: directory to zip: '${dName}${bName}'"

  # due to zip being kind of stupid, we need to cd to the base
  # dir and then run it, otherwise it may put the full path in
  # zip archive

  cd "${dName}"

  #       -r    create recursive zip file
  #       -e    encrypt
  #
  #     -df     include only data-fork of files zipped
  #     -dg     display dots
  #     -n x:x  do not compress types
  #
  #
#  zip -rn "${cList}" --quiet "${zipFile}" "${bName}"
  zip -r --quiet "${zipFile}" "${bName}"

  status=$?                           # status of last command run

  if [ $status -eq 0 ]; then          # print name if successful
    echo "${func}: wrote '${zipFile}'"
  fi

}		# eo MakeZip()

  if [ $# -ne 2 ]; then
    echo "Usage: ${0} inDir outDir"
    echo
    exit 1
  fi

  iDir="${1}"
  oDir="${2}"

  MakeZip "${iDir}" "${oDir}"

exit 0
