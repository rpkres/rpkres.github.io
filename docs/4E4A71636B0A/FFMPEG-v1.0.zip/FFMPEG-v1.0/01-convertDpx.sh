#!/bin/bash

#set -o xtrace
#set -o pipefail                # any piped command fails will stop
set -eu                         # -e stop on errors, -u stop on unset vars
                                # note, exits in sourced functions don't work

#	Includes the following functions:
#
#	  BuildTextOverlay
# 	  Usage
#
. 00-Functions.sh	

  #	Just give a single arg for long usage
  #
  if [ $# -eq 1 ]; then LongUsage; fi

  #	Bared-assed arument checking, just check number of args passed
  #
  if [ $# -ne 8 ]; then Usage; fi

  #	No sanity checking done on passed arguments - so don't fuck up
  #	what you enter on the command line.
  #
#Usage:  ${theScript} start width type fps overlay lutPath inPath outPath

  theStart=${1} 
  theWidth=${2}
  theType="${3}"
  theFps=${4}
  theOverlay=${5}
  theLutPath="${6}"
  theInPath="${7}"
  theOutPath="${8}"

  addTimeCodeInfo=false			# global checked in the overlay func

  bName=$(basename ${theLutPath} .cube)		# nuke suffix as well as dirs

  if [ "${bName}" != "NO-LUT" ]; then
    if [ ! -f "${theLutPath}" ]; then
      echo "${0}: Bailing. Can't locate lut file: '${theLutPath}'"
      exit 1
    fi
  fi

  #	Start by setting video filter with fps value
  #
  #     This is the proper way to define 23.976 and 29.97 fps for film
  #
  #             fps=24000/1001  = 23.976 
  #             fps=30000/1001  = 29.970
  #
  #	If the line is commented out, won't be used, and the var gets 
  #	set to $theFps from the command line.
  #
  theFilmFps="((${theFps}*1000)/1001)"

  #	If $theFilmFps is defined, use it - otherwise assign $theFps
  #
  theFilmFps="${theFilmFps:-${theFps}}"

  #	Assign filter fps to whatever $theFilmFps is set to
  #
  filter="fps=${theFilmFps}"

  #	Add scale to video filter if needed.
  #
  #     if $theWidth is passed as a string, all hell will break loose.
  #
  #     if $theWidth is a float
  #       if $theWidth is not 1.0 
  #         set the filter to scale the input width * the value specified.
  #     else it's an integer
  #       if $theWidth is not 1 
  #         set the filter to use the value specified for output width.
  #       
  #     some codecs require even width/height to be exactly divisable by a 
  #     macroblock size (2, 4, 8 etc.) and may barf if the scaled values 
  #     don't fit. 
  #
  if [ -z "${theWidth##*.*}" ]; then
    if [ ! "${theWidth}" == "1.0" ]; then
      filter+=",scale=iw*${theWidth}:-1"
    fi
  else
    if [ ! ${theWidth} -eq 1 ]; then
      filter+=",scale=${theWidth}:-1"
    fi
  fi

  echo "filter so far: '${filter}'"

  #	Set file name and codec stuff based on whether the output is
  #	a movie of still image(s).
  #
  # The possible video profile values for the ProRes codec prores_ks are:
  #	5 = 4444 XQ, 4 = 4444, 3 = HQ, 2 = standard, 1 = light, 0 = proxy
  #

  case "${theType}" in
    "jpeg" | "jpg" )
	encoderArgs="-f image2 -qscale:v 1"
	;;
    "mjpg" | "mjpeg" ) 
	encoderArgs="-c:v mjpeg -qscale:v 1"
	encoderArgs+=" -movflags +faststart"
	addTimeCodeInfo=true
	;;
    "mp4" )
	encoderArgs="-c:v libx264 -crf 18"
	encoderArgs+=" -pix_fmt yuv420p"		#  8bit 4:2:0
#	encoderArgs+=" -pix_fmt yuv420p10le"		# 10bit 4:2:0
	encoderArgs+=" -movflags +faststart"
	addTimeCodeInfo=true
	;;
    "png" )
	encoderArgs="-f image2"
	;;
    "prores" )
	encoderArgs="-c:v prores_ks -profile:v 3"
	encoderArgs+=" -movflags +faststart"
	addTimeCodeInfo=true
	;;
    "tif" | "tiff" )
	encoderArgs="-f image2"
#	codexArgs+="-pix_fmt rgb24"
	encoderArgs+=" -compression_algo lzw"
	;;
     * ) 
	echo "Bailing. Unrecognized output type: '${1}'"
	exit 1
	;;
  esac

  oDir=$(dirname "${theOutPath}")

  #	Create output directory if it doesn't exist
  #
  if [ ! -d "${oDir}" ]; then mkdir "${oDir}"; fi

#
#	Pass as video filter for rescaling etc.
#
#	Add lut
#
#	Reference for zscale matrix:
#		https://ffmpeg.org/ffmpeg-filters.html#zscale-1
#
#filter+=",lut3d=${lut},zscale=matrix=709,format=yuv444p10le"
#filter+=",lut3d=${lut},zscale=matrix=709"

  if [ "${theLutPath}" != "NO-LUT" ]; then
    echo "Adding LUT to filter"
    filter+=",lut3d=${theLutPath}"
  fi
  filter+=",zscale=matrix=709"

echo "filter after adding lut: '${filter}'"
echo

  #	If overlay info is 'true' and..
  #	  If function that builds the ffmpeg drawtext string is defined...
  #	    Call the function and add it to the filter.
  #
  #	    ${addTimeCodeInfo} is checked within the function and just
  #	    added to video and not still images.
  #
  if [ "${theOverlay}" == "true" ]; then
    if [ $(declare -F "BuildTextOverlay") ]; then
      textFilter=$( BuildTextOverlay "${bName}" )
      filter+=",${textFilter}"
    fi
  fi

  #	Build vars for metadata - should break out to a function at some point.	
  #
  #	QuickTime Player 7 shows different info for .mov vs .mp4's
  #	QuickTime Player X shows less information
  #	synopsis only seems to end up in .mp4s
  #	
  theTitle="${bName}"
  theYear=$(date +"%Y")
  copyChar=$( echo -e "\xc2\xa9" )        # converts to utf-8 for (c) char
  theUser="${USER}"
  theScript="${PWD}/$(basename \"${0}\")"

  theCopyright="${copyChar} ${theYear} ${theUser}, all rights reserved."
  theArtist="${theUser}"
  theAuthor="${theUser}"
  theKeywords="dpx,transcode"
  theComment="lut: ${bName}.cube"
  theDescription="ffmpeg dpx transcode"
  theInformation="${theDescription}"
  theLongDesc="${theScript}
start=${theStart}
width=${theWidth}
type=${theType}
fps=${theFps}
overlay=${theOverlay}
lutPath=\"${theLutPath}\"
inPath=\"${theInPath}\"
outPath=\"${theOutPath}\"
"
  theDirector="${theUser}"

  ffmpeg -hide_banner -y			\
	-analyzeduration 5M -probesize 5M	\
	-f image2 				\
        -start_number ${theStart}		\
        -i "${theInPath}"          		\
	-vf "${filter}"         		\
	${encoderArgs}				\
  	-metadata title="${theTitle}"			\
  	-metadata copyright="${theCopyright}"		\
  	-metadata artist="${theArtist}"			\
	-metadata keywords="${theKeywords}"		\
	-metadata description="${theDescription}"	\
	-metadata comment="${theComment}"		\
	-metadata synopsis="${theLongDesc}"		\
	-metadata director="${theDirector}"		\
	-metadata year="${theYear}"			\
	-metadata com.apple.quicktime.displayname="${theTitle}"		\
	-metadata com.apple.quicktime.copyright="${theCopyright}"	\
	-metadata com.apple.quicktime.artist="${theArtist}"		\
	-metadata com.apple.quicktime.author="${theAuthor}"		\
	-metadata com.apple.quicktime.keywords="${theKeywords}"		\
	-metadata com.apple.quicktime.comment="${theComment}"		\
	-metadata com.apple.quicktime.information="${theInformation}"	\
	-metadata com.apple.quicktime.description="${theDescription}"	\
	-metadata com.apple.quicktime.director="${theDirector}"		\
	-metadata com.apple.quicktime.year="${theYear}"			\
	"${theOutPath}"

#  	-metadata author="${theAuthor}"      # redundant?
#	-metadata information="${theInformation}"    # redundant?

  echo
#  echo "final filter: '${filter}'"
  echo "encoderArgs: '${encoderArgs}'"
  echo "outPath: '${theOutPath}'"

exit 0
