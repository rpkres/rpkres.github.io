#
#	Use indirect reference for 1st arg when calling
#
function CheckMimeType()
{
local theRef=$1
local theMimeType="${2}"
local result="true"

  local lhs="${theMimeType%%/*}"	# get lhs of '/' from end 
  local rhs="${theMimeType#*/}"		# get rhs of '/' from start

#  echo "lhs: '${lhs}' rhs: '${rhs}'"

  #	Check mimetype is one exiftool can handle
  #
  #	unrecognized: .ktx, .pntg, .sgi, .tga
  #	
  #	file: application/octet-stream:	.ktx, .pct, .pntg, .sgi
  #
  #	would have to hack around octet-stream for .pct/pict files
  #
  #	exiftool can't write or fucks up the following types:
  #
  #  "bmp"         ) ;;
  #  "heic"        ) ;;
  #  "pdf"         ) ;;
  #  "x-ms-bmp"    ) ;;
  #  "x-exr"       ) ;;
  #  "x-quicktime" ) ;;
  #
  case ${rhs} in
    "gif"  ) ;;
    "jp2"  ) ;;
    "jpeg" ) ;;
    "pict" ) ;;
    "png"  ) ;;
    "tiff" ) ;;
#    "m4a"  ) ;;
#    "mp4"  ) ;;
#    "mov"  ) ;;
    "vnd.adobe.photoshop" ) ;;
    "x-portable-bitmap"   ) ;;
         * ) result="false";;
  esac

  printf -v ${theRef} "${result}"

}			# eo CheckMimeType()
