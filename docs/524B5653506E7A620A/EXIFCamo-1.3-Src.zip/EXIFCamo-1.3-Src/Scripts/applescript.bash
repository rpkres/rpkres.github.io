#	Applescript reference links
#
#	https://apple.stackexchange.com/questions/328557/how-do-i-let-applescript-choose-any-type-of-file
#
#	https://developer.apple.com/library/archive/documentation/LanguagesUtilities/Conceptual/MacAutomationScriptingGuide/PromptforaFileorFolder.html#//apple_ref/doc/uid/TP40016239-CH81-SW1


#	Note:
#
#	$CanStr is a global bash var with the text for Cancel buttons.
#	$IconPath is a global bash var and expected to be set.
#
Timeout=3600		# n seconds timeout for dialog/file boxes etc.

#       Display Dialog via osascript (cli AppleScript)
#
function DoDialog()
{
local	theRef=$1
local   theMsg="${2}"
local   title="${AppName}"
local	result

result="$(osascript<<EOD
  set myIconPath to ("${IconPath}" as POSIX file)

  try
    display	dialog "${theMsg}" ¬
		with title "${AppName}" ¬
		buttons {"OK" } ¬
		default button "OK"  ¬
		with icon alias myIconPath ¬
		giving up after ${Timeout}
  on error
    return false
  end try

  set theButton to the button returned of the result
EOD
)"

  #	$result will be empty if timeout reached, so set it
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

  printf -v $theRef "${result}"

}               # eo DoDialog


#	Use indirect reference var when calling to store result
#
#
function GetTaskAction()
{
local theRef=$1
local theMsg="${2}"
local result

result="$(osascript<<EOD

  set myIconPath to ("${IconPath}" as POSIX file)

  try
    display	dialog "${theMsg}" ¬
		with title "${AppName}" ¬
		buttons {"Add", "Extract", "${CanStr}" } ¬
		default button "${CanStr}"  ¬
		with icon alias myIconPath ¬
		giving up after ${Timeout}

  on error
    return "${CanStr}"
  end try

  set theButton to the button returned of the result

EOD
)" 

  #	$result will be empty if timeout reached, so set it
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

  printf -v $theRef "${result}"

}               # eo GetTaskAction()


#
#	Select payload file to encode
#
function GetPayloadPath()
{
local theRef=$1
local theMsg="${2}"
local theDir="${3}"
local result
local func="${FUNCNAME}"

#echo "${func}"

  if [ "${theDir}" == "." ]; then theDir="${PWD}"; fi

result="$(osascript<<EOD

  tell application "System Events"
    set oldApp to first process whose frontmost is true
  end tell

  tell application "Finder"
    activate

    set myPath to ("${theDir}" as POSIX file)

    try
      set myItem to (choose file with prompt "${theMsg}" ¬
		     default location alias myPath )
    on error
      tell oldApp to set frontmost to true
      return "${CanStr}"
    end try

--      quoted form of ¬
    set myPath to ¬
        POSIX path of (myItem as string)

    tell oldApp to set frontmost to true

    copy myPath to stdout

  end tell
EOD
)"
  #	In case $result is empty due to OS timeout
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

  printf -v $theRef "${result}"

}		# eo GetPayloadPath()

#	Save Document prompt
#
function GetSavefilePath()
{
local theRef=$1
local theMsg="${2}"
local thePath="${3}"
local result
local func="${FUNCNAME}"

  local theDir=$(dirname "${thePath}")
  local theBase=$(basename "${thePath}")

  if [ "${theDir}" == "." ]; then theDir="${PWD}"; fi

result="$(osascript<<EOD

  tell application "System Events"
    set oldApp to first process whose frontmost is true
  end tell

  tell application "Finder"
    activate

    set myPath to ("${theDir}" as POSIX file)

    try
      set myItem to (choose file name with prompt "${theMsg}" ¬
		     default name "${theBase}" ¬
		     default location alias myPath )
    on error
      tell oldApp to set frontmost to true
      return "${CanStr}"
    end try

    set myPath to ¬
        POSIX path of (myItem as string)

    tell oldApp to set frontmost to true

--      quoted form of ¬
    copy myPath to stdout

  end tell
EOD
)"

  #	In case $result is empty due to OS timeout
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

  printf -v $theRef "${result}"

}		# eo GetSavefilePath()


function GetPassword()
{
local theRef=$1
local theMsg="${2}"
local theDefault="${3}"
local result

result="$( osascript<<EOD

  set myIconPath to ("${IconPath}" as POSIX file)

  try
    display dialog "${theMsg}"  ¬
	default answer "${theDefault}"  ¬
	with title "${AppName}" ¬
        buttons { "${CanStr}", "OK" } ¬
        default button "OK" ¬
	with icon alias myIconPath ¬
	giving up after ${Timeout}

  on error
    return "${CanStr}"
  end try

--  set theButton to the button returned
  set theAnswer to the text returned of the result
--  set theButton to the button returned of the result

EOD
)"

  #	In case $result is empty due to timeout
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

  printf -v ${theRef} "${result}"

}		# eo GetPassword()

#	Use indirect reference var when calling to store result
#
#
function TagOptions()
{
local theRef=$1
local theMsg="${2}"
local result

#  local theMsg="Strip old EXIF Image Tags?\r\rFile: ${theFile}"

result="$(osascript<<EOD

  set myIconPath to ("${IconPath}" as POSIX file)

  try
    display	dialog "${theMsg}" ¬
		with title "${AppName}" ¬
		buttons {"No", "Yes" } ¬
		default button "Yes"  ¬
		with icon alias myIconPath ¬
		giving up after ${Timeout}

  on error
    return "${CanStr}"
  end try

  set theButton to the button returned of the result

EOD
)" 

# cancel button "Cancel"

  #	$result will be empty if timeout reached, so set it
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

#echo "result: '${result}'"

  printf -v $theRef "${result}"

}               # eo TagOptions()

function SetLabelIndex()
{
local theFile="${1}"
local result

result="$( osascript<<EOD

tell application "Finder"

  set myPath to ("${theFile}" as POSIX file) as alias

  try
    set the label index of myPath to 5
  on error
    return "${CanStr}"
  end try

end tell
EOD
)"

#  echo -e "result: '${result}'"
}		# eo SetLabel()

#
#       Send a keyboard key to a specific application
#
function SendKey()
{
local theKey="${1}"
local theApp="${2}"
local theCode

  case ${theKey} in
         "home" ) theCode=115;;
      "page up" ) theCode=116;;
          "end" ) theCode=119;;
    "page down" ) theCode=121;;
   "arrow left" ) theCode=123;;
  "arrow right" ) theCode=124;;
   "arrow down" ) theCode=125;;
     "arrow up" ) theCode=126;;
              * ) theCode=$( printf "%.0f" $theKey );;       # cast to int
  esac

#echo "theCode: '${theCode}'"

osascript<<EOD

  tell application "System Events"
    tell application "${theApp}" to activate
      key code ${theCode}
  end tell

EOD

}               # eo SendKey()
