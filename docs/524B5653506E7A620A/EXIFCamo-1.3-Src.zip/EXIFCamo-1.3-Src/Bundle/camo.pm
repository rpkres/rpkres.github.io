#               This example file defines the following 16 new tags as well as
#               a number of Shortcut and Composite tags:
#
#                   1.  EXIF:CamoEXIFTag
#                   2.  GPS:GPSPitch
#                   3.  GPS:GPSRoll
#                   4.  IPTC:CamoIPTCTag
#                   5.  XMP-xmp:CamoXMPxmpTag
#                   6.  XMP-exif:GPSPitch
#                   7.  XMP-exif:GPSRoll
#                   8.  XMP-xxx:CamoXMPxxxTag1
#                   9.  XMP-xxx:CamoXMPxxxTag2
#                  10.  XMP-xxx:CamoXMPxxxTag3
#                  11.  XMP-xxx:CamoXMPxxxStruct
#                  12.  PNG:CamoPngTag1
#                  13.  PNG:CamoPngTag2
#                  14.  PNG:CamoPngTag3
#                  15.  MIE-Meta:CamoMieTag1
#                  16.  MIE-Test:CamoMieTag2
#
#               For detailed information on the definition of tag tables and
#               tag information hashes, see lib/Image/ExifTool/README.
#------------------------------------------------------------------------------


# Shortcut tags are used when extracting information to simplify
# commonly used commands.  They can be used to represent groups
# of tags, or to provide an alias for a tag name.
#%Image::ExifTool::UserDefined::Shortcuts = (
#    MyShortcut => ['exif:createdate','exposuretime','aperture'],
#    MyAlias => 'FocalLengthIn35mmFormat',
#);

# NOTE: All tag names used in the following tables are case sensitive.

# The %Image::ExifTool::UserDefined hash defines new tags to be added
# to existing tables.

#use Image::ExifTool qw(:DataAccess :Utils);
#use Image::ExifTool qw(:Utils :Vars);
use Image::ExifTool::Exif;

%Image::ExifTool::UserDefined = (
    # All EXIF tags are added to the Main table, and WriteGroup is used to
    # specify where the tag is written (default is ExifIFD if not specified):
    'Image::ExifTool::Exif::Main' => {
#    PROCESS_PROC => \&Image::ExifTool::ProcessBinaryData,
#    WRITE_PROC => \&Image::ExifTool::WriteBinaryData,
#    CHECK_PROC => \&Image::ExifTool::CheckBinaryData,
    WRITABLE => 1,
        # Example 1.  EXIF:CamoEXIFTag
#        0xd000 => {
#            Name => 'CamoInt',
#            Writable => 'int16u',
#            WriteGroup => 'IFD0',
#        },
#        0xd001 => {
#            Name => 'CamoString',
#            Writable => 'string',
#            WriteGroup => 'IFD0',
#        },
	0xd00d => {
	    Name => 'CamoLUT',
            Format => 'undef',
            Writable => 'undef',
            Binary => 1,
        Flags => [ 'Binary' ],
	},
    },
);

# https://exiftool.org/forum/index.php?topic=7377.0
#%Image::ExifTool::UserDefined = (
#    'Image::ExifTool::XMP::xmp' => {
#        # URL tag (simple string, no checking, we specify the name explicitly so it stays all uppercase)
#        URL => { Name => 'URL' },
#        # Text tag (can be specified in alternative languages)
#        Text => { Writable => 'lang-alt' },
#    },
#);



# Change default location for writing QuickTime tags so Keys is preferred
# (by default, the PREFERRED levels are: ItemList=2, UserData=1, Keys=0)
use Image::ExifTool::QuickTime;
$Image::ExifTool::QuickTime::Keys{PREFERRED} = 3;

# Specify default ExifTool option values
# (see the Options function documentation for available options)
%Image::ExifTool::UserDefined::Options = (
    CoordFormat => '%.6f',  # change default GPS coordinate format
    Duplicates => 1,        # make -a default for the exiftool app
    GeoMaxHDOP => 4,        # ignore GPS fixes with HDOP > 4
    RequestAll => 3,        # request additional tags not normally generated
);



#------------------------------------------------------------------------------
1;  #end
