#!/bin/bash

set -eu                         # -e stop on errors, -u stop on unset vars

function BuildZip()
{
local iDir="${1}"
local oDir="${2}"
local func="${FUNCNAME}"

  if [ ! -d "${iDir}" ]; then
    echo "Skipping. Directory doesn't exist: '${iDir}'"
    return
  fi

  if [ ! -d "${oDir}" ]; then mkdir -p "${oDir}"; fi

  #
  #     List of file types that are already compressed, no need to
  #     waste cpu trying to re-compress.
  #
  local cList=".bmp:.exr:.gif:.heic:.jp2:.jpg:.jpeg:.ktx:.pbm:.pct:.pdf:.png:.pntg:.psd:.qtif:.sgi:.tga:.tiff"

  local dName=$(dirname "${iDir}")	# Get the leading part of $iDir in
                                	# case it's a full path.

  local bName=$(basename "${iDir}")	# Just the last part of the path 
					# name of $iDir in case a full path 
					# is given.
                                	# Used to construct a matching name 
					# for the zip file.

  #     If in same directory, just blank out $dName
  #     else append a slash
  #
  if [ "${dName}" = "." ]; then 
    dName=""
  else                          
    dName="${dName}/"           
  fi

  local zipFile="${oDir}/${bName}.zip"        

  echo "${func}: Directory to zip: '${dName}${bName}'"

  # due to zip being kind of stupid, we need to cd to the base
  # dir and then run it, otherwise it may put the full path in
  # zip archive

  cd "${dName}"

  #       -r    create recursive zip file
  #       -e    encrypt
  #
  #     -df     include only data-fork of files zipped
  #     -dg     display dots
  #     -n x:x  do not compress specified file types
  #
  #
#  zip -rn "${cList}" --exclude \*.DS_Store --symlinks --quiet \
  zip -r --symlinks --exclude \*.DS_Store --quiet \
	"${zipFile}" "${bName}"

  status=$?                           # status of last command run

  if [ $status -eq 0 ]; then          # print name if successful
    echo "${func}: wrote '${zipFile}'"
  fi

}		# eo BuildZip()

  if [ $# -ne 2 ]; then
    echo "Usage: ${0} inDir outDir"
    echo
    exit 1
  fi

  iDir="${1}"
  oDir="${2}"

  BuildZip "${iDir}" "${oDir}"

exit 0
