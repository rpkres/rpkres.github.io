#!/bin/sh

#set -o pipefail                # any piped command fails will stop

set -eu                         # -e stop on errors, -u stop on unset vars
                                # note, exits in sourced functions don't work

  prog=$(basename $0)

  if [ $# -ne 1 ]; then
    echo "Usage: ${prog} output-application-name"
    exit 1
  fi

  theAppName="${1}"			# arg 1 supplied on command line
  theAppName=$(basename "${theAppName}" .app)	# strip .app suffix if supplied

  theVersion=${APP_VERSION:-"0.0b"}	  # if env var not defined, use 0.0b

  theAuthor="${USER}"
  theBundleID="net.rodian.${theAppName}"  # OS ID in reverse domain notation

echo "theAppName: '${theAppName}' - (version: ${theVersion})"

  baseDir="${PWD}"			# Full path of this directory

  theScript="${baseDir}/Scripts/${theAppName}.sh"
  theIcon="${baseDir}/Artwork/Icon.icns"

  for theFile in $theScript $theIcon; do
    if [ ! -f "${theFile}" ]; then
      echo "${prog}. Bailing, unable to access file: '${theFile}'"
      exit 1
    fi
  done

theInterfaceType="Text Window"
#theInterfaceType="Droplet"

#	Programs/files to be bundled in the final app. They get copied
#	to the Resources folder of the final app.
#
#"--bundled-file Scripts/applescript.bash"
#"--bundled-file Scripts/create.bash"
#"--bundled-file Scripts/extract.bash"
#"--bundled-file Scripts/usage.bash"

theBundledFiles=(
"--bundled-file Scripts/functions.bash"
"--bundled-file Bundle/exiftool"
"--bundled-file Bundle/lib"
"--bundled-file Bundle/camo.pm"
)

#	Note - 'Draws Background' is off in Nid, so background
#		color won't show up
#

theTextColor="#000000"
#"#1ee705"  		
theBgColor="#FAF6ED"
#theBgColor="#CBCBCB"
#theBgColor="#A6A6A6"
#theBgColor="#f6f6f6"
#theBgColor="#e3e3e3"
#"#050505"  	
#theTextFont="SFMono-Medium 20"
#theTextFont="SFMono-Regular 14"
#theTextFont="Menlo-Regular 14"
#theTextFont="Monaco-Regular 14"
#theTextFont="Monaco-Regular 18"
#theTextFont="Monaco 18"
theTextFont="Monaco 14"

#develop="--symlink"

/usr/local/bin/platypus 				\
	--name "${theAppName}"				\
	--author "${theAuthor}"				\
	--app-version "${theVersion}"			\
	${develop:-}					\
	--overwrite					\
	--droppable					\
	--app-icon "${theIcon}"  			\
  	--interface-type "${theInterfaceType}" 		\
	--interpreter-args "-l" 			\
	--interpreter "/bin/bash"   			\
	--bundle-identifier "${theBundleID}"  		\
	--text-foreground-color "${theTextColor}"	\
	--text-background-color "${theBgColor}"		\
	--text-font             "${theTextFont}"  	\
	${theBundledFiles[@]}				\
	"${theScript}"					\
	"${baseDir}/${theAppName}"

#cd "Nib/${theInterfaceType}"
cd "Nib"
tar cf /tmp/z.tar MainMenu.nib
cd "${baseDir}/${theAppName}.app/Contents/Resources"
tar xf /tmp/z.tar
ls -l

#	--uniform-type-identifiers "public.item|public.folder" \

exit 0
