
#	Store return in indirect reference var
#
function GetPlistItemForKey()
{
local theRef=$1
local theKey="${2}"
local thePass="${3}"
local thePlist="${4}"
local keyData
local theVal

  set +e
  keyData=$( /usr/libexec/PlistBuddy \
	    -c "print :${theKey}" "${pFile}" 2>/dev/null)
  set -e

  #	If empty, set to $PkeyErr and return
  #
  if [ "${keyData}" == "" ]; then
    printf -v ${theRef} "${PkeyErr}"
    return
  fi

#  echo "${FUNCNAME}: theResult: '${theResult}'"

  #	Decrypt $keyData
  #
  set +e
  theVal=$(echo -e "${keyData}" | \
	/usr/bin/base64 -D | \
	/usr/bin/openssl enc -aes256 -d -pass pass:"${thePass}" 2>/dev/null)

  set -e

  #	Assume bad password if $theVal is empty...
  #
  if [ "${theVal}" == "" ]; then theVal="${PpassErr}"; fi

  if (($Debug)); then
    printf "${FUNCNAME}: theKey: %-12s theVal: '${theVal}'\n" ${theKey}
  fi

  printf -v ${theRef} "${theVal}"

}		#eo GetPlistItemForKey()



function ExtractHandler()
{
local imgFile="${1}"
#local payFile
local outFile
local theMsg
local result
local func="${FUNCNAME}"

  echo -e "\rExtract Payload.\r"

  #     Temp plist file
  #
  local pFile="${TmpDir}/tmp.plist"

  #     Temp decrypted files
  #
#  local eNameFile="${TmpDir}/tmp.name.dec"
#  local ePaylFile="${TmpDir}/tmp.payl.dec"

#  if [ -f "${pFile}" ]; then rm -f "${pFile}"; fi
  NukeFile "${pFile}"

  #	Make sure there's a payload
  #
  #	exiftool is so fucked up in how it handles $status and has fucked
  #	up conditionals -if blah, so we'll first test for the payload.
  #
#  ./exiftool -config ./camo.pm -b -CamoLUT "${imgFile}" > "${pFile}"
  local status
  status=$( ./exiftool -config ./camo.pm -s -CamoLUT "${imgFile}" 2>/dev/null)

  if [ "${status}" == "" ]; then

    theMsg="No Payload In File:"
    local bName=$(basename "${iFile}")

    echo -e "● ${theMsg} '${bName}'"
    DoDialog result "${theMsg}\r\r${bName}"

    return
  fi

  #	Extract payload to plist file
  #
  ./exiftool -config ./camo.pm -b -CamoLUT "${imgFile}" > "${pFile}" 2>/dev/null

  #	Get the password, will loop until a match - user gets to cancel.
  #
  local thePass=""
  local pVersion=0 
  local pTime=0

  while ((1)) ; do

    GetPassword thePass "Enter Payload Password:" "${PWord}"
    if [ "${thePass}" == "${CanStr}" ]; then echo "Cancelled."; return; fi

    #	Extract payload name key from plist - base64 decode - decrypt
    #
    #	unset bash internal -e (stop on error) and set it back when done.
    #
    #	ideally if I'd added a version earlier, that would be a good
    #	thing to test against, but for backwards compatibilty sakes we'll
    #	check against the name
    #
  #  set +e
  #  status=$(
#	/usr/libexec/PlistBuddy -c "print :${PnameKey}" "${pFile}" | \
#	/usr/bin/base64 -D | \
#	/usr/bin/openssl enc -aes256 -d -pass pass:"${thePass}" 2>/dev/null)
#    set -e

    #	Get the payload version - key name and password need to match
    #
    GetPlistItemForKey result "${PversKey}" "${thePass}" "${pFile}"

    case ${result} in
	"${PkeyErr}" )
	  DoDialog result "Fatal Error. Can't find key: '${PversKey}'"
	  return
	;;
	"${PpassErr}" )
          DoDialog result "Password Mismatch, Try Again."
	;;
 	"" )
	  DoDialog result "Fatal Error. Empty value"
	  return
	;;
	* )
	  break;		# break out of while loop
	;;
    esac

  done

  pVersion=$(printf "%.0f" ${result})	# cast to int

  #	Get the payload timestamp
  #
  GetPlistItemForKey result "${PtimeKey}" "${thePass}" "${pFile}"

  if [ "${result}" == "${PkeyErr}"  ] ||
     [ "${result}" == "${PpassErr}" ]; then 
    DoDialog result "Skip extraction. No payload time stamp found".
    return
  fi
  pTime=$(printf "%.0f" ${result}); 	# cast to int

  #	Get the payload name
  #
  GetPlistItemForKey result "${PnameKey}" "${thePass}" "${pFile}"

  if [ "${result}" == "${PkeyErr}"  ] ||
     [ "${result}" == "${PpassErr}" ]; then 
    DoDialog result "Skip extraction. No payload file name found".
    return
  fi

  #	Construct the extraction file name based on 
  #	the payload file name.
  #
  local paylName="${result}"

  local theDir=$(dirname "${imgFile}")
  local theBase=$(basename "${paylName}")

  local lhs="${theBase%.*}"             # everything left of last period
  local suffix="${theBase:${#lhs}}"     # index start = size of $lhs

#  local thePath="${theDir}/${lhs}-xtr${suffix}"

  #	Default path to save payload to
  #
  local thePath="${theDir}/${lhs}${suffix}"

  #	If the file already exists in the imgDir, change the name
  #
  if [ -f "${thePath}" ]; then 
    thePath="${theDir}/${Prefix}${lhs}${suffix}"
  fi

  local payFile
  theMsg="Save payload file to:"

#  echo "  ● ${theMsg}"

  GetSavefilePath payFile "${theMsg}" "${thePath}"

  if [ "${payFile}" == "${CanStr}" ]; then echo "Cancelled."; return; fi

  #	Extract/decode/decrypt payload to $payFile
  #
  #	This should be more bullet proof - like above key check
  #
  /usr/libexec/PlistBuddy -c "print :${PpaylKey}" "${pFile}" | \
  /usr/bin/base64 -D | \
  /usr/bin/openssl enc -aes256 -d -pass pass:"${thePass}" > "${payFile}"

  #	Set the ouput file's timestamp to the store one.
  #

  # convert seconds to fmt for touch(1): “[[CC]YY]MMDDhhmm[.SS]”
  #
  local tDate=$(/bin/date -j -r "${pTime}" +"%Y%m%d%H%M.%S")

  if (($Debug)); then
    echo -en "Setting timestamp to: "; date -r "${pTime}"
  fi

  #	Set modification and access time to timestamp of 
  #	original payload file.
  #
  /usr/bin/touch -t "${tDate}" "${payFile}"

  #     Set the output payload file's color tag label
  #
  SetLabelIndex "${payFile}"

  echo -e "Done."

}		# eo ExtractHandler()
