#!/bin/sh

  set -eu			# -e stop on errors, -u stop on unset vars

#iFile="rpkStripEXIF@2x.pdf"
#iFile="rpkStripEXIF@2x.png"

  prog=$(basename $0)

#  if [ $# -ne 1 ]; then
#    echo "Usage: ${prog} input-image-file.[pdf|png]"
#    exit 1
#  fi

#  iFile="${1}"

#  if [ ! -f "${iFile}" ]; then
#    echo "${prog}. Bailing, unable to access file: '${iFile}'."
#    exit 1
#  fi

  bName="Icon"
  oFile="${bName}.icns"
  iSet="${bName}.iconset"


#if [ -d "${iSet}" ]; then rm -rf "${iSet}"; fi
#mkdir "${iSet}"

oBase="${iSet}/icon"		# system name for file base

iconutil -c icns "${iSet}" -o "${oFile}"

exit 0
