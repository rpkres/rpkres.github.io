#!/bin/bash

#exec 2>&1
#exec 1>&2

set -eu					# bail on error/undefined vars

OIFS=$IFS                               # store original IFS
IFS=$'\t\n'                             # set to leave spaces intact
#IFS=$OIFS                              # reset IFS to original setting

  #	Some global vars
  #
  CanStr="Cancel"			# Used for button text and checking

  PnameKey="Gamma"			# plist key to store filename
  PpaylKey="LUT"			# plist key to store payload data

  Debug=0				# prints more info if > 0

  #	Default password for encrypting/decrypting payload.
  #
  #	Note that this lessens OpenSSL security dramatically as the
  #	password can be seen by orher processes such as ps(1)
  #
#  PWord="Hi, hi, hi there, my little droogies."
#  PWord="I've taught you much, my little droogies."
  PWord="Long time no viddy, droog. How goes?"
#  PWord="Right, Right, Right, my little droogies."

  Prefix="camo."		# used as default for output file names

  ExifTool="${PWD}/exiftool"		# This app's version
  ExifConfig="${PWD}/camo.pm"		# custom exiftool tag handler (perl)

  ExifCode="Exif_0xd00d"		# The tag id defined in camo.pm


  #	The following file contains all functions and needs to be
  #	added to ../platypusBuild.sh as an app bundles.
  #
  source ./functions.bash

  SetProgramName ProgName "${0}"		# sets $ProgName

  TmpDir="${TMPDIR:-/var/tmp/}${ProgName}/TemporaryItems"	# tmp files

  if [ ! -d "${TmpDir}" ]; then mkdir -p "${TmpDir}"; fi

  IconPath="${PWD}/AppIcon.icns"

  logFile="/dev/null"
  logFile="${logFile:-"/dev/stdout"}"		# if commented out

  #	Not sure if traps are getting run under Platypus...
  #
#  if [ $(declare -F CleanUp) ]; then trap CleanUp EXIT; fi
  trap CleanUp EXIT

  if [ $# -le 0 ]; then Usage; fi

  noArgs=$(($# > 0 ? 0 : 1))

#echo "num args: $#"
#echo "noArgs: $noArgs"
#echo "iconFile: '${iconFile}'"
#echo ""

#DoDialog

# ˚̊ ̊ ̥ · ° ˙ ̈ ̤ • ┉ ┄ ╌ ╍ ═ ─

  ul=""; for (( n=0; n < 80; n++ )); do ul+="·"; done

  while [ $# -gt 0 ]
  do

    iFile="${1}"
    strLen="${#iFile}"

    #	Note that 'file' reports several image types as
    #	application/octet-stream - it affects pict file parsing
    #
    mimeType=$( /usr/bin/file --brief --mime-type "${iFile}" )

#    lhs="${mimeType%%/*}"		# get lhs of '/' from end 
#    rhs="${mimeType#*/}"		# get rhs of '/' from start

	cat <<-EOD
${ul}
input file: '${iFile}'
  mimeType: '${mimeType}'
${ul}
	EOD

    #	Check mimetype is one exiftool can handle
    #
    CheckMimeType isOK "${mimeType}"

    if [ "${isOK}" == "false" ]; then 
      msg="Cannot Process This Kind Of File:"
      bName=$(basename "${iFile}")
      echo "● ${msg} '${bName}'"
      DoDialog ignoreResult "${msg}\r\r${bName}"
      shift; continue; 
    fi

    #	Get task
    #
    GetTaskAction action "$(basename "${iFile}")"

    case "${action}" in
      "Add"       ) AddHandler     "${iFile}" ;;
      "Extract"   ) ExtractHandler "${iFile}" ;;
      "${CanStr}" ) echo "Cancelled.";;		# user hit 'esc' or 'cancel'
                * ) echo "Skipping. Unknown task action: '${action}'";;
    esac

    shift

  done

#  CleanUp

  echo -e "\r${ul}"
  echo -e "● Drag another image onto this window for further processing."

exit 0

#	eo main.bash
