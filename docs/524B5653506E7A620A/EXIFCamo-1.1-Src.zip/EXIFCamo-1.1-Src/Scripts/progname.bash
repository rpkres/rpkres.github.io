#	Pass a var name (no dollar sign) and the main $0 to this
#	function to determine the program name when being used 
#	as a Platypus application.
#
#	example $0 when run from a platypus build:
#
# /Users/rpk/Documents/Platypus/UITest/UITest.app/Contents/Resources/script
#
function SetProgramName()
{
local theRef=${1}		# indirect reference var
local theStr="${2}"

  local base="${theStr%.app*}"	# lhs of .app from rear of $theStr
  local pre=${base%/*}		# lhs of '/' from rear of $base

  local result="${base#${pre}/}"	# subtract $pre and '/' from $base

  printf -v ${theRef} "${result}"

#echo "variable named: '$theRef' set to: '${!theRef}'"

}		# eo SetProgramName()
