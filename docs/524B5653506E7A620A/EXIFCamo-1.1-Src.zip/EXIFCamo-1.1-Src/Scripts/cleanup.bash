#	Remove temp files - this function is also tied to trap exit
#
#	$TmpDir is a global var
#
function CleanUp()
{ 
local func="${FUNCNAME}"

  if [ -d "${TmpDir}" ]; then 
    if (($Debug)); then echo "${func}: nuking: '${TmpDir}'"; fi
#ls -lR "${TmpDir}"
    rm -rf "${TmpDir}"; 
  fi

}               # eo CleanUp()

#	Generic file remove
#
function NukeFile()
{
local theFile="${1}"

  if [ -f "${theFile}" ]; then rm -f "${theFile}"; fi

}		# eo NukeFile()

#	Change whitespace chars to uri format, uses indirect reference
#	on passed var.
#
function CleanWhitespace()
{
local theRef=$1
local theString="${!theRef}"	# copy current contents of passed iref var

  theString="${theString//$'\t'/%09}"		# sub tabs
  theString="${theString//[[:space:]]/%20}"	# sub other whitespace chars

  #	copy results back to passed indirect reference
  #
  printf -v ${theRef} "%s" "${theString}"

}		# eo CleanWhiteSpace()
