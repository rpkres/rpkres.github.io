
function Usage()
{
local skip=".bmp, .exr, .heic, .ktx, .pdf, .pntg, .sgi, .tga, .qtif"

echo -e "\r${FUNCNAME}:\r"

cat <<EOD

Drag an image file to this window and you will be prompted to Add or Extract a Payload file.
	
Add:	  
	
	Store a Payload file in a copy of the input image and save as 
	a new image file.
	
	● A file browser is presented to select a Payload file.
	
	● When prompted, enter a password to be used to encrypt the 
	  Payload.
	
	● A file browser is presented to select a place and name for
	  the new image file.
	
	● The final prompt asks whether to clear any tags in the new copy.
	
	● Once the new file has been save, some EXIF info is printed.
	
Extract:  
	
	Extract and save the Payload from an image file.
	
	● Prompts for the password orignally used to encrypt the Payload.
	
	● A file browser is presented to select a place and name for the 
	  extracted Payload.
	
notes: 
	
	● The following image file types cannot be processed:
	
	    ${skip}
	
	● The Payload is stored in a custom EXIF tag in the image file
	  using the tag id: ${ExifCode}.
	
	● If you modify the output file with an editing app, the payload
	  will likely be removed by that app.
	
	● Files created or extracted by ${ProgName} have a Purple Finder
	  tag set.
EOD

  #	Adds yet another thing to give permission to and is slow.
  #
#  SendKey "home" "${ProgName}"		# move scroll bar to top of page

#or ⌘-Q to quit.

exit 1
}		# eo Usage()
