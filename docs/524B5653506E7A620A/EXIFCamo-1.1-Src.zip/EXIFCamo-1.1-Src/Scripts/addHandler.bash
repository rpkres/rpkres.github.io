
#	Handles all the steps in creating a new file with a payload
#
function AddHandler()
{
local imgFile="${1}"		# image file
local payFile			# payload file
local outFile			# output file
local theMsg
#local func="${ProgName}:${FUNCNAME}"
local func="Create"

  echo -e "\rAdd Payload.\r"

  #	Get the payload file, default to same dir as image file.
  #
  local theDir=$(dirname "${imgFile}")
  local baseName=$(basename "${imgFile}")

  theMsg="Select Payload File To Add To ${baseName}"

  GetPayloadPath payFile "${theMsg}" "${theDir}"

  if [ "${payFile}" == "${CanStr}" ]; then echo "Cancelled."; return; fi



  #     Add fixed password to encryption routines - note they will show
  #     up in a ps(1) listing, so this isn't optimal, however certs will
  #     make payloads much larger and more complexity etc.
  # 
  local thePass=""

  GetPassword thePass "Enter a Password to Encrypt Payload:" "${PWord}"

  if [ "${thePass}" == "${CanStr}" ]; then echo "Cancelled."; return; fi

#  Pword="${thePass}"			# as the user might test the 
#  CleanWhitespace pWord

  #	Get SaveFile path, assume same directory as payload file
  #
  theDir=$(dirname "${payFile}" )

  local theBase=$(basename "${imgFile}")
  local lhs="${theBase%.*}"             # everything left of last period
  local suffix="${theBase:${#lhs}}"     # index start = size of $lhs

  local thePath="${theDir}/${Prefix}${lhs}${suffix}"

  theMsg="Save File With Payload As:"

#  echo "  ● ${theMsg}"
  GetSavefilePath outFile "${theMsg}" "${thePath}"

  if [ "${outFile}" == "${CanStr}" ]; then echo "Cancelled."; return; fi

#  if (($Debug)); then
cat<<EOD
  input file: '${imgFile}'
payload file: '${payFile}'
   save file: '${outFile}'
EOD
#  fi
#    password: '${thePass}'

  #	Prompt whether to clear old tags.
  #
  local clearTags

  TagOptions clearTags "$(basename "${outFile}")"

  if [ "${clearTags}" == "${CanStr}" ]; then
    echo -e "\rInternal Error. That shouldn't have happened!\r"
    return
  fi

  if (($Debug)); then echo "  Clear tags? ${clearTags}"; fi

  #	Temp plist and encrypted files.
  #
  local pFile="${TmpDir}/tmp.plist"
  local eNameFile="${TmpDir}/tmp.name.enc"
  local ePaylFile="${TmpDir}/tmp.payl.enc"

  #	Nuke old plist
  #
  NukeFile "${pFile}"


  #	Encrypt/Encode filename
  #
  if (($Debug)); then echo "  Encrypting filename"; fi

  /usr/bin/basename "${payFile}" | \
  /usr/bin/openssl enc -aes256 -e -salt -pass pass:"${thePass}" | \
  /usr/bin/base64 > "${eNameFile}"

  #	Encrypt/Encode Payload
  #
  if (($Debug)); then echo "  Encrypting payload"; fi

  /bin/cat "${payFile}" | \
  /usr/bin/openssl enc -aes256 -e -salt -pass pass:"${thePass}" | \
  /usr/bin/base64 > "${ePaylFile}"

  #	camouflage Salted__ magic number in place
  #
#  /usr/bin/vim -u NONE -b -n \
#	-c ":g/${CryptMagic}/s//${CryptLocum}/" 
#	-c ":wq!" \
#	"${eFile}"

  #	Create plist file.
  #
  #	Import encrypted data to plist file - PlistBuddy *appears* to
  #	automatically base64 the data if not already in that format
  #
  if (($Debug)); then echo "  Creating property list file"; fi

  /usr/libexec/PlistBuddy \
			  -c "import :${PnameKey} ${eNameFile}" \
			  -c "import :${PpaylKey} ${ePaylFile}" \
			   "${pFile}" 1>/dev/null

  #	Make sure plist is binary
  #
  /usr/bin/plutil -convert binary1 "${pFile}"

  #	Just to be on the safe side with exiftool, nuke	$outFile 
  #
  NukeFile "${outFile}"

  #	If this var is not commented...
  #
  #	Exiftool is fucked (and slow) when trying to strip all tags
  #	and then rotate, so break into 2 passes. Ridiculous.
  #
  #
#  strip="-all:all= -tagsfromfile @ -exif:Orientation"
  local strip

  if [ "${clearTags}" == "Yes" ]; then
    strip="-all:all="
  fi
#strip="-all"


  #	If $strip is set and has a value
  #
  if [ "${strip:-}" != "" ]; then echo -e "  ● Stripping old tags\r"; fi


  if (($Debug)); then echo "  Adding property list as an exif tag"; fi

  #	strip old vars if set and load our payload tag direct from file
  #
  "${ExifTool}" -config "${ExifConfig}" -s \
		-quiet		\
		${strip:-}	\
		"-CamoLUT<=${pFile}" \
		-out "${outFile}" \
		"${imgFile}"

  #	if old tags have been remove ($clearTags = Yes) then if old image
  #	has a rotation setting (-Orientation) apply it to the output file.
  #
  if [ "${clearTags}" == "Yes" ]; then
#  if [ "${strip:-}" != "" ]; then
    local orient=$( "${ExifTool}" -n -s -s -s -Orientation "${imgFile}" )

    if [ "${orient}" != "" ]; then
      "${ExifTool}" -config "${ExifConfig}" \
		  -quiet	\
		  -overwrite_original \
		  -Orientation=${orient} -n	\
		  "${outFile}"
    fi
  fi


  echo -e "${ul}"
#    echo -e "Reading newly embedded tag\r"
  echo -e "${outFile}:"
  echo -e "${ul}"

  #	So many flags/output from exiftool are so fucked, this sort of
  #	works in the platypus window environment
  #
  #	There seems to be some weird bug with the -unknown flag run this
  #	way - nothing gets output, so using sed(1) to fix
  #
#local info="$( "${ExifTool}" -config "${ExifConfig}" \
#--MDItemFS:all -all:all -s "${outFile}" )"

  "${ExifTool}"	-config "${ExifConfig}" \
		--File:all --ProcessingTime -s "${outFile}" | \
		sed -e "s/CamoLUT    /${ExifCode}/"

  echo -e "\rnote: suppressed 'File' tags"
  echo -e "${ul}"

  #	Set the output file's color tag label
  #
  SetLabelIndex "${outFile}"

  echo -e "Done."

}		# eo AddHandler()
