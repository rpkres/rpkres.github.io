
function ExtractHandler()
{
local imgFile="${1}"
local payFile
local outFile
local theMsg
local result
local func="${FUNCNAME}"

  echo -e "\rExtract Payload.\r"

  #     Temp plist file
  #
  local pFile="${TmpDir}/tmp.plist"

  #     Temp decrypted files
  #
#  local eNameFile="${TmpDir}/tmp.name.dec"
#  local ePaylFile="${TmpDir}/tmp.payl.dec"

#  if [ -f "${pFile}" ]; then rm -f "${pFile}"; fi
  NukeFile "${pFile}"

  #	Make sure there's a payload
  #
  #	exiftool is so fucked up in how it handles $status and has fucked
  #	up conditionals -if blah, so we'll first test for the payload.
  #
#  ./exiftool -config ./camo.pm -b -CamoLUT "${imgFile}" > "${pFile}"
  local status
  status=$( ./exiftool -config ./camo.pm -s -CamoLUT "${imgFile}" 2>/dev/null)

  if [ "${status}" == "" ]; then

    theMsg="No Payload In File:"
    local bName=$(basename "${iFile}")

    echo -e "● ${theMsg} '${bName}'"
    DoDialog result "${theMsg}\r\r${bName}"

    return
  fi

  #	Extract payload to plist file
  #
  ./exiftool -config ./camo.pm -b -CamoLUT "${imgFile}" > "${pFile}" 2>/dev/null

  #	Get the password, will loop until a match - user gets to cancel.
  #
  local thePass=""

  while ((1)) ; do

    GetPassword thePass "Enter a Password for Payload:" "${PWord}"
    if [ "${thePass}" == "${CanStr}" ]; then echo "Cancelled."; return; fi

    #	Extract payload name key from plist - base64 decode - decrypt
    #
    #	unset bash internal -e (stop on error) and set it back when done.
    #
    set +e
    status=$(
	/usr/libexec/PlistBuddy -c "print :${PnameKey}" "${pFile}" | \
	/usr/bin/base64 -D | \
	/usr/bin/openssl enc -aes256 -d -pass pass:"${thePass}" 2>/dev/null)
    set -e

    if [ "${status}" != "" ]; then break; fi

    DoDialog result "Password Mismatch, Try Again."

  done

  local paylName="${status}"

  local theDir=$(dirname "${imgFile}")
  local theBase=$(basename "${paylName}")

  local lhs="${theBase%.*}"             # everything left of last period
  local suffix="${theBase:${#lhs}}"     # index start = size of $lhs

#  local thePath="${theDir}/${lhs}-xtr${suffix}"

  #	Default path to save payload to
  #
  local thePath="${theDir}/${lhs}${suffix}"

  #	If the file already exists in the imgDir, change the name
  #
  if [ -f "${thePath}" ]; then 
    thePath="${theDir}/${Prefix}${lhs}${suffix}"
  fi

  theMsg="Save payload file to:"

#  echo "  ● ${theMsg}"

  GetSavefilePath payFile "${theMsg}" "${thePath}"

  if [ "${payFile}" == "${CanStr}" ]; then echo "Cancelled."; return; fi
#  echo -e "\t${payFile}"

#  touch "${payFile}"
#  touch -r "${imgFile}" "${payFile}"

  #	Extract/decode/decrypt payload to $payFile
  #
  /usr/libexec/PlistBuddy -c "print :${PpaylKey}" "${pFile}" | \
  /usr/bin/base64 -D | \
  /usr/bin/openssl enc -aes256 -d -pass pass:"${thePass}" > "${payFile}"

  #     Set the output file's color tag label
  #
  SetLabelIndex "${payFile}"


  echo -e "Done."

}		# eo ExtractHandler()
