#!/bin/bash

set -eu

  #	Prints the file(1) definition of mimetypes to stdout 
  #
  #	note: exiftool doesn't always match the same type.
  #

  iBase="IMG_0039"

  list=$(/bin/ls ${iBase}.*)

  arr=(${list})
  nItems=${#arr[@]}

  for ((i=0; i < $nItems; i++)); do
    iFile="${arr[$i]}"
    file --mime-type "${iFile}" 
  done

exit 0
