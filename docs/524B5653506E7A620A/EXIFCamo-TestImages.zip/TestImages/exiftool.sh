#!/bin/bash

#set -eu
set -u

  #	Run exiftool to print tags on image files it can recognize
  #
  iBase="IMG_0039"

  list=$(/bin/ls ${iBase}.*)

  arr=(${list})
  nItems=${#arr[@]}

  for ((i=0; i < $nItems; i++)); do
    iFile="${arr[$i]}"
    echo "--------------"
    echo "${iFile}"
    exiftool "${iFile}"
    echo
  done

exit 0
