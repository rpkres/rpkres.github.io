AppName=EXIFCamo
AppVersion=1.2		
PayloadVersion=1


#	Applescript reference links
#
#	https://apple.stackexchange.com/questions/328557/how-do-i-let-applescript-choose-any-type-of-file
#
#	https://developer.apple.com/library/archive/documentation/LanguagesUtilities/Conceptual/MacAutomationScriptingGuide/PromptforaFileorFolder.html#//apple_ref/doc/uid/TP40016239-CH81-SW1


#	Note:
#
#	$CanStr is a global bash var with the text for Cancel buttons.
#	$IconPath is a global bash var and expected to be set.
#
Timeout=3600		# n seconds timeout for dialog/file boxes etc.

#       Display Dialog via osascript (cli AppleScript)
#
function DoDialog()
{
local	theRef=$1
local   theMsg="${2}"
local   title="${AppName}"
local	result

result="$(osascript<<EOD
  set myIconPath to ("${IconPath}" as POSIX file)

  try
    display	dialog "${theMsg}" ¬
		with title "${AppName}" ¬
		buttons {"OK" } ¬
		default button "OK"  ¬
		with icon alias myIconPath ¬
		giving up after ${Timeout}
  on error
    return false
  end try

  set theButton to the button returned of the result
EOD
)"

  #	$result will be empty if timeout reached, so set it
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

  printf -v $theRef "${result}"

}               # eo DoDialog


#	Use indirect reference var when calling to store result
#
#
function GetTaskAction()
{
local theRef=$1
local thePath="${2}"
local result

#  local theMsg="\rSelect EXIF operation to perform on image:\r\r${thePath}\r\r"
#  local theMsg="Select Create or Extract Payload using image:\r\r${thePath}\r\r"
  local theMsg="Select payload action to perform on:\r\r${thePath}\r\r"

result="$(osascript<<EOD

  set myIconPath to ("${IconPath}" as POSIX file)

  try
    display	dialog "${theMsg}" ¬
		with title "${AppName}" ¬
		buttons {"Add", "Extract", "${CanStr}" } ¬
		default button "${CanStr}"  ¬
		with icon alias myIconPath ¬
		giving up after ${Timeout}

  on error
    return "${CanStr}"
  end try

  set theButton to the button returned of the result

EOD
)" 

  #	$result will be empty if timeout reached, so set it
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

  printf -v $theRef "${result}"

}               # eo GetTaskAction()


#
#	Select payload file to encode
#
function GetPayloadPath()
{
local theRef=$1
local theMsg="${2}"
local theDir="${3}"
local result
local func="${FUNCNAME}"

#echo "${func}"

  if [ "${theDir}" == "." ]; then theDir="${PWD}"; fi

result="$(osascript<<EOD

  tell application "System Events"
    set oldApp to first process whose frontmost is true
  end tell

  tell application "Finder"
    activate

    set myPath to ("${theDir}" as POSIX file)

    try
      set myItem to (choose file with prompt "${theMsg}" ¬
		     default location alias myPath )
    on error
      tell oldApp to set frontmost to true
      return "${CanStr}"
    end try

--      quoted form of ¬
    set myPath to ¬
        POSIX path of (myItem as string)

    tell oldApp to set frontmost to true

    copy myPath to stdout

  end tell
EOD
)"
  #	In case $result is empty due to OS timeout
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

  printf -v $theRef "${result}"

}		# eo GetPayloadPath()

#	Save Document prompt
#
function GetSavefilePath()
{
local theRef=$1
local theMsg="${2}"
local thePath="${3}"
local result
local func="${FUNCNAME}"

  local theDir=$(dirname "${thePath}")
  local theBase=$(basename "${thePath}")

  if [ "${theDir}" == "." ]; then theDir="${PWD}"; fi

result="$(osascript<<EOD

  tell application "System Events"
    set oldApp to first process whose frontmost is true
  end tell

  tell application "Finder"
    activate

    set myPath to ("${theDir}" as POSIX file)

    try
      set myItem to (choose file name with prompt "${theMsg}" ¬
		     default name "${theBase}" ¬
		     default location alias myPath )
    on error
      tell oldApp to set frontmost to true
      return "${CanStr}"
    end try

    set myPath to ¬
        POSIX path of (myItem as string)

    tell oldApp to set frontmost to true

--      quoted form of ¬
    copy myPath to stdout

  end tell
EOD
)"

  #	In case $result is empty due to OS timeout
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

  printf -v $theRef "${result}"

}		# eo GetSavefilePath()


function GetPassword()
{
local theRef=$1
local theMsg="${2}"
local theDefault="${3}"
local result

result="$( osascript<<EOD

  set myIconPath to ("${IconPath}" as POSIX file)

  try
    display dialog "${theMsg}"  ¬
	default answer "${theDefault}"  ¬
	with title "${AppName}" ¬
        buttons { "${CanStr}", "OK" } ¬
        default button "OK" ¬
	with icon alias myIconPath ¬
	giving up after ${Timeout}

  on error
    return "${CanStr}"
  end try

--  set theButton to the button returned
  set theAnswer to the text returned of the result
--  set theButton to the button returned of the result

EOD
)"

  #	In case $result is empty due to timeout
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

  printf -v ${theRef} "${result}"

}		# eo GetPassword()

#	Use indirect reference var when calling to store result
#
#
function TagOptions()
{
local theRef=$1
local theFile="${2}"
local result

  local theMsg="Clear copied EXIF Image Tags?\r\rFile: ${theFile}"

result="$(osascript<<EOD

  set myIconPath to ("${IconPath}" as POSIX file)

  try
    display	dialog "${theMsg}" ¬
		with title "${AppName}" ¬
		buttons {"No", "Yes" } ¬
		default button "Yes"  ¬
		with icon alias myIconPath ¬
		giving up after ${Timeout}

  on error
    return "${CanStr}"
  end try

  set theButton to the button returned of the result

EOD
)" 

# cancel button "Cancel"

  #	$result will be empty if timeout reached, so set it
  #
  if [ "${result}" == "" ]; then result="${CanStr}"; fi

#echo "result: '${result}'"

  printf -v $theRef "${result}"

}               # eo TagOptions()

function SetLabelIndex()
{
local theFile="${1}"
local result

result="$( osascript<<EOD

tell application "Finder"

  set myPath to ("${theFile}" as POSIX file) as alias

  try
    set the label index of myPath to 5
  on error
    return "${CanStr}"
  end try

end tell
EOD
)"

#  echo -e "result: '${result}'"
}		# eo SetLabel()

#
#       Send a keyboard key to a specific application
#
function SendKey()
{
local theKey="${1}"
local theApp="${2}"
local theCode

  case ${theKey} in
         "home" ) theCode=115;;
      "page up" ) theCode=116;;
          "end" ) theCode=119;;
    "page down" ) theCode=121;;
   "arrow left" ) theCode=123;;
  "arrow right" ) theCode=124;;
   "arrow down" ) theCode=125;;
     "arrow up" ) theCode=126;;
              * ) theCode=$( printf "%.0f" $theKey );;       # cast to int
  esac

#echo "theCode: '${theCode}'"

osascript<<EOD

  tell application "System Events"
    tell application "${theApp}" to activate
      key code ${theCode}
  end tell

EOD

}               # eo SendKey()

#	Handles all the steps in creating a new file with a payload
#
function AddHandler()
{
local imgFile="${1}"		# image file
local payFile			# payload file
local outFile			# output file
local theMsg
#local func="${AppName}:${FUNCNAME}"
local func="Create"

  echo -e "\rAdd Payload.\r"

  #	Get the payload file, default to same dir as image file.
  #
  local theDir=$(dirname "${imgFile}")
  local baseName=$(basename "${imgFile}")

  theMsg="Select Payload File To Add To ${baseName}"

  GetPayloadPath payFile "${theMsg}" "${theDir}"

  if [ "${payFile}" == "${CanStr}" ]; then echo "Cancelled."; return; fi



  #     Add fixed password to encryption routines - note they will show
  #     up in a ps(1) listing, so this isn't optimal, however certs will
  #     make payloads much larger and more complexity etc.
  # 
  local thePass=""

  GetPassword thePass "Enter a Password to Encrypt Payload:" "${PWord}"

  if [ "${thePass}" == "${CanStr}" ]; then echo "Cancelled."; return; fi

#  Pword="${thePass}"			# as the user might test the 
#  CleanWhitespace pWord

  #	Get SaveFile path, assume same directory as payload file
  #
  theDir=$(dirname "${payFile}" )

  local theBase=$(basename "${imgFile}")
  local lhs="${theBase%.*}"             # everything left of last period
  local suffix="${theBase:${#lhs}}"     # index start = size of $lhs

  local thePath="${theDir}/${Prefix}${lhs}${suffix}"

  theMsg="Save File With Payload As:"

#  echo "  ● ${theMsg}"
  GetSavefilePath outFile "${theMsg}" "${thePath}"

  if [ "${outFile}" == "${CanStr}" ]; then echo "Cancelled."; return; fi

  #	Get timestamp of payload file to store as plist entry.
  #	Use 'modified' date. Value in seconds.
  #	Add -r if we need epoch seconds
  #
  local pTime=$( /usr/bin/stat -f "%m" "${payFile}" )

#  if (($Debug)); then
cat<<EOD
  input file: '${imgFile}'
payload file: '${payFile}'
   save file: '${outFile}'
payload time: '${pTime}'
EOD
#  fi
#    password: '${thePass}'

  #	Prompt whether to clear old tags.
  #
  local clearTags

  TagOptions clearTags "$(basename "${outFile}")"

  if [ "${clearTags}" == "${CanStr}" ]; then
    echo -e "\rInternal Error. That shouldn't have happened!\r"
    return
  fi

  if (($Debug)); then echo "  Clear tags? ${clearTags}"; fi

  #	Temp plist and encrypted files.
  #
  local pFile="${TmpDir}/tmp.plist"
  local eVersFile="${TmpDir}/tmp.vers.enc"
  local eNameFile="${TmpDir}/tmp.name.enc"
  local eTimeFile="${TmpDir}/tmp.time.enc"
  local ePaylFile="${TmpDir}/tmp.payl.enc"

  #	Nuke old plist
  #
  NukeFile "${pFile}"

  #	Encrypt/Encode payload version
  #
  if (($Debug)); then echo "  Encrypting payload version"; fi

  echo -n "${PayloadVersion}" | \
  /usr/bin/openssl enc -aes256 -e -salt -pass pass:"${thePass}" | \
  /usr/bin/base64 > "${eVersFile}"

  #	Encrypt/Encode filename
  #
  if (($Debug)); then echo "  Encrypting filename"; fi

  /usr/bin/basename "${payFile}" | \
  /usr/bin/openssl enc -aes256 -e -salt -pass pass:"${thePass}" | \
  /usr/bin/base64 > "${eNameFile}"

  #	Encrypt/Encode payload version
  #
  if (($Debug)); then echo "  Encrypting timestamp"; fi

  echo -n "${pTime}" | \
  /usr/bin/openssl enc -aes256 -e -salt -pass pass:"${thePass}" | \
  /usr/bin/base64 > "${eTimeFile}"

  #	Encrypt/Encode Payload
  #
  if (($Debug)); then echo "  Encrypting payload"; fi

  /bin/cat "${payFile}" | \
  /usr/bin/openssl enc -aes256 -e -salt -pass pass:"${thePass}" | \
  /usr/bin/base64 > "${ePaylFile}"

  #	camouflage Salted__ magic number in place
  #
#  /usr/bin/vim -u NONE -b -n \
#	-c ":g/${CryptMagic}/s//${CryptLocum}/" 
#	-c ":wq!" \
#	"${eFile}"

  #	Create plist file.
  #
  #	Import encrypted data to plist file - PlistBuddy *appears* to
  #	automatically base64 the data if not already in that format
  #
  if (($Debug)); then echo "  Creating property list file"; fi

  /usr/libexec/PlistBuddy \
			  -c "import :${PversKey} ${eVersFile}" \
			  -c "import :${PnameKey} ${eNameFile}" \
			  -c "import :${PtimeKey} ${eTimeFile}" \
			  -c "import :${PpaylKey} ${ePaylFile}" \
			   "${pFile}" 1>/dev/null


  #	Make sure plist is binary
  #
  /usr/bin/plutil -convert binary1 "${pFile}"

  #	Just to be on the safe side with exiftool, nuke	$outFile 
  #
  NukeFile "${outFile}"

  #	If this var is not commented...
  #
  #	Exiftool is fucked (and slow) when trying to strip all tags
  #	and then rotate, so break into 2 passes. Ridiculous.
  #
  #
#  strip="-all:all= -tagsfromfile @ -exif:Orientation"
  local strip

  if [ "${clearTags}" == "Yes" ]; then
    strip="-all:all="
  fi
#strip="-all"


  #	If $strip is set and has a value
  #
  if [ "${strip:-}" != "" ]; then echo -e "  ● Stripping old tags\r"; fi


  if (($Debug)); then echo "  Adding property list as an exif tag"; fi

  #	strip old vars if set and load our payload tag direct from file
  #
  "${ExifTool}" -config "${ExifConfig}" -s \
		-quiet		\
		${strip:-}	\
		"-CamoLUT<=${pFile}" \
		-out "${outFile}" \
		"${imgFile}"

  #	if old tags have been remove ($clearTags = Yes) then if old image
  #	has a rotation setting (-Orientation) apply it to the output file.
  #
  if [ "${clearTags}" == "Yes" ]; then
#  if [ "${strip:-}" != "" ]; then
    local orient=$( "${ExifTool}" -n -s -s -s -Orientation "${imgFile}" )

    if [ "${orient}" != "" ]; then
      "${ExifTool}" -config "${ExifConfig}" \
		  -quiet	\
		  -overwrite_original \
		  -Orientation=${orient} -n	\
		  "${outFile}"
    fi
  fi


  echo -e "${ul}"
#    echo -e "Reading newly embedded tag\r"
  echo -e "${outFile}:"
  echo -e "${ul}"

  #	So many flags/output from exiftool are so fucked, this sort of
  #	works in the platypus window environment
  #
  #	There seems to be some weird bug with the -unknown flag run this
  #	way - nothing gets output, so using sed(1) to fix
  #
#local info="$( "${ExifTool}" -config "${ExifConfig}" \
#--MDItemFS:all -all:all -s "${outFile}" )"

  "${ExifTool}"	-config "${ExifConfig}" \
		--File:all --ProcessingTime -s "${outFile}" | \
		sed -e "s/CamoLUT    /${ExifCode}/"

  echo -e "\rnote: suppressed 'File' tags"
  echo -e "${ul}"

  #	Set the output file's color tag label
  #
  SetLabelIndex "${outFile}"

  echo -e "Done."

}		# eo AddHandler()
#
#	Use indirect reference for 1st arg when calling
#
function CheckMimeType()
{
local theRef=$1
local theMimeType="${2}"
local result="true"

  local lhs="${theMimeType%%/*}"	# get lhs of '/' from end 
  local rhs="${theMimeType#*/}"		# get rhs of '/' from start

#  echo "lhs: '${lhs}' rhs: '${rhs}'"

  #	Check mimetype is one exiftool can handle
  #
  #	unrecognized: .ktx, .pntg, .sgi, .tga
  #	
  #	file: application/octet-stream:	.ktx, .pct, .pntg, .sgi
  #
  #	would have to hack around octet-stream for .pct/pict files
  #
  #	exiftool can't write or fucks up the following types:
  #
  #  "bmp"         ) ;;
  #  "heic"        ) ;;
  #  "pdf"         ) ;;
  #  "x-ms-bmp"    ) ;;
  #  "x-exr"       ) ;;
  #  "x-quicktime" ) ;;
  #
  case ${rhs} in
    "gif"  ) ;;
    "jp2"  ) ;;
    "jpeg" ) ;;
    "pict" ) ;;
    "png"  ) ;;
    "tiff" ) ;;
    "vnd.adobe.photoshop" ) ;;
    "x-portable-bitmap"   ) ;;
         * ) result="false";;
  esac

  printf -v ${theRef} "${result}"

}			# eo CheckMimeType()

#	Store return in indirect reference var
#
function GetPlistItemForKey()
{
local theRef=$1
local theKey="${2}"
local thePass="${3}"
local thePlist="${4}"
local keyData
local theVal

  set +e
  keyData=$( /usr/libexec/PlistBuddy \
	    -c "print :${theKey}" "${pFile}" 2>/dev/null)
  set -e

  #	If empty, set to $PkeyErr and return
  #
  if [ "${keyData}" == "" ]; then
    printf -v ${theRef} "${PkeyErr}"
    return
  fi

#  echo "${FUNCNAME}: theResult: '${theResult}'"

  #	Decrypt $keyData
  #
  set +e
  theVal=$(echo -e "${keyData}" | \
	/usr/bin/base64 -D | \
	/usr/bin/openssl enc -aes256 -d -pass pass:"${thePass}" 2>/dev/null)

  set -e

  #	Assume bad password if $theVal is empty...
  #
  if [ "${theVal}" == "" ]; then theVal="${PpassErr}"; fi

  if (($Debug)); then
    printf "${FUNCNAME}: theKey: %-12s theVal: '${theVal}'\n" ${theKey}
  fi

  printf -v ${theRef} "${theVal}"

}		#eo GetPlistItemForKey()



function ExtractHandler()
{
local imgFile="${1}"
#local payFile
local outFile
local theMsg
local result
local func="${FUNCNAME}"

  echo -e "\rExtract Payload.\r"

  #     Temp plist file
  #
  local pFile="${TmpDir}/tmp.plist"

  #     Temp decrypted files
  #
#  local eNameFile="${TmpDir}/tmp.name.dec"
#  local ePaylFile="${TmpDir}/tmp.payl.dec"

#  if [ -f "${pFile}" ]; then rm -f "${pFile}"; fi
  NukeFile "${pFile}"

  #	Make sure there's a payload
  #
  #	exiftool is so fucked up in how it handles $status and has fucked
  #	up conditionals -if blah, so we'll first test for the payload.
  #
#  ./exiftool -config ./camo.pm -b -CamoLUT "${imgFile}" > "${pFile}"
  local status
  status=$( ./exiftool -config ./camo.pm -s -CamoLUT "${imgFile}" 2>/dev/null)

  if [ "${status}" == "" ]; then

    theMsg="No Payload In File:"
    local bName=$(basename "${iFile}")

    echo -e "● ${theMsg} '${bName}'"
    DoDialog result "${theMsg}\r\r${bName}"

    return
  fi

  #	Extract payload to plist file
  #
  ./exiftool -config ./camo.pm -b -CamoLUT "${imgFile}" > "${pFile}" 2>/dev/null

  #	Get the password, will loop until a match - user gets to cancel.
  #
  local thePass=""
  local pVersion=0 
  local pTime=0

  while ((1)) ; do

    GetPassword thePass "Enter Payload Password:" "${PWord}"
    if [ "${thePass}" == "${CanStr}" ]; then echo "Cancelled."; return; fi

    #	Extract payload name key from plist - base64 decode - decrypt
    #
    #	unset bash internal -e (stop on error) and set it back when done.
    #
    #	ideally if I'd added a version earlier, that would be a good
    #	thing to test against, but for backwards compatibilty sakes we'll
    #	check against the name
    #
  #  set +e
  #  status=$(
#	/usr/libexec/PlistBuddy -c "print :${PnameKey}" "${pFile}" | \
#	/usr/bin/base64 -D | \
#	/usr/bin/openssl enc -aes256 -d -pass pass:"${thePass}" 2>/dev/null)
#    set -e

    #	Get the payload version - key name and password need to match
    #
    GetPlistItemForKey result "${PversKey}" "${thePass}" "${pFile}"

    case ${result} in
	"${PkeyErr}" )
	  DoDialog result "Fatal Error. Can't find key: '${PversKey}'"
	  return
	;;
	"${PpassErr}" )
          DoDialog result "Password Mismatch, Try Again."
	;;
 	"" )
	  DoDialog result "Fatal Error. Empty value"
	  return
	;;
	* )
	  break;		# break out of while loop
	;;
    esac

  done

  pVersion=$(printf "%.0f" ${result})	# cast to int

  #	Get the payload timestamp
  #
  GetPlistItemForKey result "${PtimeKey}" "${thePass}" "${pFile}"

  if [ "${result}" == "${PkeyErr}"  ] ||
     [ "${result}" == "${PpassErr}" ]; then 
    DoDialog result "Skip extraction. No payload time stamp found".
    return
  fi
  pTime=$(printf "%.0f" ${result}); 	# cast to int

  #	Get the payload name
  #
  GetPlistItemForKey result "${PnameKey}" "${thePass}" "${pFile}"

  if [ "${result}" == "${PkeyErr}"  ] ||
     [ "${result}" == "${PpassErr}" ]; then 
    DoDialog result "Skip extraction. No payload file name found".
    return
  fi

  #	Construct the extraction file name based on 
  #	the payload file name.
  #
  local paylName="${result}"

  local theDir=$(dirname "${imgFile}")
  local theBase=$(basename "${paylName}")

  local lhs="${theBase%.*}"             # everything left of last period
  local suffix="${theBase:${#lhs}}"     # index start = size of $lhs

#  local thePath="${theDir}/${lhs}-xtr${suffix}"

  #	Default path to save payload to
  #
  local thePath="${theDir}/${lhs}${suffix}"

  #	If the file already exists in the imgDir, change the name
  #
  if [ -f "${thePath}" ]; then 
    thePath="${theDir}/${Prefix}${lhs}${suffix}"
  fi

  local payFile
  theMsg="Save payload file to:"

#  echo "  ● ${theMsg}"

  GetSavefilePath payFile "${theMsg}" "${thePath}"

  if [ "${payFile}" == "${CanStr}" ]; then echo "Cancelled."; return; fi

  #	Extract/decode/decrypt payload to $payFile
  #
  #	This should be more bullet proof - like above key check
  #
  /usr/libexec/PlistBuddy -c "print :${PpaylKey}" "${pFile}" | \
  /usr/bin/base64 -D | \
  /usr/bin/openssl enc -aes256 -d -pass pass:"${thePass}" > "${payFile}"

  #	Set the ouput file's timestamp to the store one.
  #

  # convert seconds to fmt for touch(1): “[[CC]YY]MMDDhhmm[.SS]”
  #
  local tDate=$(/bin/date -j -r "${pTime}" +"%Y%m%d%H%M.%S")

  if (($Debug)); then
    echo -en "Setting timestamp to: "; date -r "${pTime}"
  fi

  #	Set modification and access time to timestamp of 
  #	original payload file.
  #
  /usr/bin/touch -t "${tDate}" "${payFile}"

  #     Set the output payload file's color tag label
  #
  SetLabelIndex "${payFile}"

  echo -e "Done."

}		# eo ExtractHandler()
#	Remove temp files - this function is also tied to trap exit
#
#	$TmpDir is a global var
#
function CleanUp()
{ 
local func="${FUNCNAME}"

  if [ -d "${TmpDir}" ]; then 
    if (($Debug)); then echo "${func}: nuking: '${TmpDir}'"; fi
#echo "${TmpDir}"
#ls -lR "${TmpDir}"
    rm -rf "${TmpDir}"; 
  fi

}               # eo CleanUp()

#	Generic file remove
#
function NukeFile()
{
local theFile="${1}"

  if [ -f "${theFile}" ]; then rm -f "${theFile}"; fi

}		# eo NukeFile()

#	Change whitespace chars to uri format, uses indirect reference
#	on passed var.
#
function CleanWhitespace()
{
local theRef=$1
local theString="${!theRef}"	# copy current contents of passed iref var

  theString="${theString//$'\t'/%09}"		# sub tabs
  theString="${theString//[[:space:]]/%20}"	# sub other whitespace chars

  #	copy results back to passed indirect reference
  #
  printf -v ${theRef} "%s" "${theString}"

}		# eo CleanWhiteSpace()

function Usage()
{
local skip=".bmp, .exr, .heic, .ktx, .pdf, .pntg, .sgi, .tga, .qtif"

echo -e "\r${FUNCNAME}:\r"

cat <<EOD

Drag an image file to this window and you will be prompted to Add or Extract a Payload file.
	
Add:	  
	
	Store a Payload file in a copy of the input image and save as 
	a new image file.
	
	● A file browser is presented to select a Payload file.
	
	● When prompted, enter a password to be used to encrypt the 
	  Payload.
	
	● A file browser is presented to select a place and name for
	  the new image file.
	
	● The final prompt asks whether to clear any tags in the new copy.
	
	● Once the new file has been save, some EXIF info is printed.
	
Extract:  
	
	Extract and save the Payload from an image file.
	
	● Prompts for the password orignally used to encrypt the Payload.
	
	● A file browser is presented to select a place and name for the 
	  extracted Payload.
	
notes: 
	
	● The following image file types cannot be processed:
	
	    ${skip}
	
	● The Payload is stored in a custom EXIF tag in the image file
	  using the tag id: ${ExifCode}.
	
	● If you modify the output file with an editing app, the payload
	  will likely be removed by that app.
	
	● Files created or extracted by ${AppName} have a Purple Finder
	  tag set.
	
versions: app: ${AppVersion}, payload: ${PayloadVersion}

EOD

  #	Adds yet another thing to give permission to and is slow.
  #
#  SendKey "home" "${AppName}"		# move scroll bar to top of page

#or ⌘-Q to quit.

exit 1
}		# eo Usage()
