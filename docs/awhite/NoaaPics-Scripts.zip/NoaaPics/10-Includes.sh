#!/bin/bash

. 00-Shared.sh                  # Some funcs/vars shared by noaa scripts
. 00-Xattr.sh

Usage()
{
local suffix=$( GetGlobalVal suffix )
local metaKey=$( GetGlobalVal metaKey )

cat <<EOD

Usage: ${Prog} [option] firstDay lastDay directory

	-h, --help		Prints this message and exits.

	${Prog} adds the extended attriubutes to the attibute
	named ${XattrNameForDir} to the specified directory.

EOD

exit 1

}		# eo Usage()


#	EOF
