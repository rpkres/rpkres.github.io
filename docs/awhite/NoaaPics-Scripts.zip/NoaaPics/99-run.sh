#!/bin/bash

iDir="NOAA-[275-275]-1800x1080"
iDir="NOAA-[276-276]-1800x1080"
iDir="NOAA-[275-276]-1800x1080"
iDir="NOAA-[273-276]-1800x1080"

iDir="NOAA-[297-297]-1800x1080"

resolution="1800x1080"

inHeight=${resolution##*x}	# input height of downloads, rhs of the 'x' char
outHeight=840			# output height of movies

fontSize=20
footerHeight=30		# height of image footer to crop out on 1800 high image

mFile="${iDir}-x${outHeight}.mp4"	# movie file name based on $iDir


GetFiles()
{
local hStart=0
local hEnd=23
local day

  day=$(date +"%j")		# today, which is also the default

#day=298
#hEnd=3

#0-2

#	--numberOfDays 2 	\
#	--execCurl false	\

  ./01-getFiles.sh 			\
	--day ${day} 			\
	--resolution ${resolution}	\
	--hourStart ${hStart}		\
	--hourEnd ${hEnd}

}		# eo GetFiles()

MakeMp4()
{
local theHeight=$1
local theDir="${2}"

  ./03-makeMp4.sh 			\
	--outHeight ${outHeight} 	\
	--footerHeight ${footerHeight} 	\
	${theHeight} "${theDir}"

}		# eo MakeMp4()

#	Comment this to download the files for the specified hours
#
#GetFiles 

#	This gets run automatically from 01-getFiles.sh now
#
#./02-addTags.sh "${iDir}"

MakeMp4 ${inHeight} "${iDir}"

./04-iTunesMeta.sh "${mFile}"

#./10-modDirXattr.sh 273 276 "${iDir}"

exit

\ls -ld@
\ls -lf@
xattr -l foo
