#!/bin/bash

#. 00-Shared.sh 			# Some funcs/vars shared by noaa scripts
. 10-Includes.sh		# Extra funcs used by this script.

#	Globals to use in this script
#
#	Note, entries can be commented out!
#
Globals=( 
  firstDay=
  lastDay=
  directory= 
)

  #	main()

  #	Parse command line args.
  #
  if [ $# -lt 3 ]; then
    Usage
  fi

  #     Copy command line args and place in argv array and parse
  #
  #     Note use of IFS is set only for the following command (there's 
  #     no semicolon). In this case items are only split on \n, not
  #     spaces or tabs so the user can passed quoted strings with spaces
  #     as a single argument.
  #
  IFS=$'\n' argv=($*)
  argc=${#argv[@]}
  let cnt=($argc - 3)   # last args don't get parsed as options

#  PrintGlobals

  for ((i=0; i<$cnt; i++)); do

    arg="${argv[$i]}"

    case "${arg}" in
      "-h" | "--help"   ) Usage ;;
#      "-s" | "--suffix" ) 
#	let i++
#        SetGlobalVal suffix "${argv[@]:$i:1}"
#	;;
      * )
	echo -e "${Prog}. Bailing. Unrecognized option: '${arg}'."
	exit 1
    esac

  done

  #	last arg should be the directory name, can be quoted
  #
  firstDay="${argv[($argc-3)]}"
  lastDay="${argv[($argc-2)]}"
  iDir="${argv[($argc-1)]}"

  if [ $firstDay -gt $lastDay ]; then
    echo -e "Bailing. firstDay is greater than lastDay: $firstDay $lastDay"
    exit 1
  fi

  if [ ! -d "${iDir}" ]; then
    echo -e "Bailing. No such directory: '${iDir}'"
    exit 1
  fi

  SetGlobalVal firstDay ${firstDay}
  SetGlobalVal lastDay ${lastDay}
  SetGlobalVal directory "${iDir}"

#  PrintGlobals

  theData="${firstDay}${Xseperator}${lastDay}${Xseperator}${iDir}"

  SetGlobalVal "${XattrNameForDir}" "${theData}"
  WriteXattrData "${XattrNameForDir}" "${iDir}"


exit 0
